rAll(".color-dot").forEach(dot => {
  dot.addEventListener("click", () => {
    document.querySelectorAll(".color-dot").forEach(d => d.classList.remove("active"));
    dot.classList.add("active");
    bubbleColor = dot.dataset.color;
    localStorage.setItem("bubbleColor", bubbleColor);
    applyBubbleColor(bubbleColor);
  });
});

document.querySelectorAll(".mood-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".mood-btn").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    currentMood = btn.dataset.mood;
    localStorage.setItem("userMood", currentMood);
    showToast(`Mood: ${currentMood}`);
    const statusEl = document.querySelector(".chat-header-details span");
    if (statusEl) statusEl.textContent = currentMood;
  });
});

document.getElementById("closeSettingsBtn").addEventListener("click", () => {
  document.getElementById("chatSettingsModal").style.display = "none";
});

// ══════════════════════════════════════════════
//  CLOSE OVERLAYS ON BACKGROUND TAP
// ══════════════════════════════════════════════
["threadMenu","msgActionMenu","giftModal"].forEach(id => {
  document.getElementById(id)?.addEventListener("click", e => {
    if (e.target === document.getElementById(id))
      document.getElementById(id).style.display = "none";
  });
});

// ══════════════════════════════════════════════
//  INIT
// ══════════════════════════════════════════════
async function init() {
  applyBg(chatBg);
  applyBubbleColor(bubbleColor);
  await loadUserInfo();
  await loadMessages(true);
  startPolling();
}

init();
