const mongoose = require("mongoose");

const walletSchema = new mongoose.Schema({

  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    unique: true,
    required: true
  },

  availableBalance: {
    type: Number,
    default: 0
  },

  starBalance: {
    type: Number,
    default: 0
  },

  pendingBalance: {
    type: Number,
    default: 0
  },

  totalEarned: {
    type: Number,
    default: 0
  },

  walletPin: {
    type: String,
    default: null
  },

  currency: {
    type: String,
    default: "NGN"
  }

}, { timestamps: true });

module.exports =
  mongoose.model("Wallet", walletSchema);
