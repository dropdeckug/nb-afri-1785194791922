const mongoose = require("mongoose");

const messageSchema = new mongoose.Schema(
  {
    // DIRECT CHAT SUPPORT
    conversation: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Conversation",
      index: true
    },

    // GROUP CHAT SUPPORT
    group: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Group",
      index: true
    },

    sender: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true
    },

    text: {
      type: String,
      default: ""
    },

    media: {
      type: String,
      default: ""
    },

    type: {
      type: String,
      enum: ["text", "image", "video", "document", "voice", "gift"],
      default: "text"
    },

    voiceDuration: {
      type: String,
      default: ""
    },

    replyTo: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Message"
    },

    giftType: {
      type: String
    },

    giftStars: {
      type: Number,
      default: 0
    },

    // READ TRACKING (FIX FOR FUTURE GROUP CHAT SCALE)
    readBy: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
      }
    ],

    // ARCHIVE SUPPORT
    isArchived: {
      type: Boolean,
      default: false
    },

    archivedBy: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
      }
    ],

    // DELETE SUPPORT (SOFT DELETE)
    isDeleted: {
      type: Boolean,
      default: false
    },

    deletedAt: {
      type: Date
    }
  },
  { timestamps: true }
);

// INDEXES FOR SPEED
messageSchema.index({ conversation: 1, createdAt: -1 });
messageSchema.index({ group: 1, createdAt: -1 });
messageSchema.index({ sender: 1 });
messageSchema.index({ createdAt: -1 });

module.exports = mongoose.model("Message", messageSchema);
