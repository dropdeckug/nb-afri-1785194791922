// routes/messageRoutes.js
const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");
const upload = require("../middleware/upload");

const c = require("../controllers/messageController");

function uploadErrorStatus(err) {
  if (!err) return 500;
  if (err.code === "LIMIT_FILE_SIZE") return 413;
  return 500;
}

function uploadType(file) {
  const mt = (file?.mimetype || "").toLowerCase();
  if (mt.startsWith("video/")) return "video";
  if (mt.startsWith("image/")) return "image";
  if (mt.startsWith("audio/")) return "voice";
  return "document";
}

/* --- inbox / list --- */
router.get("/chats",          auth, c.getChats);
router.get("/conversations",  auth, c.getConversations);
router.get("/archived",       auth, c.getArchived);
router.get("/unread-count",   auth, c.getUnreadCount);
router.get("/search",         auth, c.searchMessages);

/* --- conversation create/send --- */
router.post("/createConversation", auth, c.createConversation);
router.post("/send",               auth, c.sendMessage);

/* --- media upload (returns {url, type}) --- */
router.post("/upload-media", auth, (req, res) => {
  upload.single("file")(req, res, (err) => {
    if (err) {
      console.error("UPLOAD MEDIA ERROR:", err);
      return res.status(uploadErrorStatus(err)).json({ message: err.message || "Upload failed" });
    }
    if (!req.file) return res.status(400).json({ message: "No file" });
    const url = req.file.path || req.file.secure_url || req.file.url;
    if (!url) {
      console.error("UPLOAD MEDIA ERROR: upload completed without URL", req.file);
      return res.status(500).json({ message: "Upload completed but no media URL was returned" });
    }
    res.json({
      url,
      type: uploadType(req.file),
      mimetype: req.file.mimetype || ""
    });
  });
});

/* --- conversation header / read state --- */
router.get("/conversation/:conversationId", auth, c.getConversation);
router.put("/read/:conversationId",         auth, c.markMessagesAsRead);

/* --- archive / clear by conversation id --- */
router.post  ("/:id/archive",     auth, c.archiveConversation);
router.post  ("/:id/unarchive",   auth, c.unarchiveConversation);
router.delete("/:id/clear",       auth, c.clearConversation);

/* --- per-recipient helpers used by the existing frontend --- */
router.post("/:userId/typing", auth, c.typing);
router.post("/:userId/read",   auth, c.markReadByUser);

/* --- delete a single message --- */
router.delete("/message/:msgId", auth, c.deleteMessage);
router.delete("/msg/:msgId",     auth, c.deleteMessage); // alias

/* --- DYNAMIC ROUTE MUST BE LAST --- */
router.get("/:conversationId", auth, c.getMessages);

module.exports = router;
