const User = require("../models/User");
const sendEmail = require("../utils/sendEmail");

// =========================
// SMALL DELAY HELPER
// =========================
const delay = (ms) =>
  new Promise(resolve =>
    setTimeout(resolve, ms)
  );

module.exports = async function sendReEngagementEmails() {

  try {

    console.log(
      "Running re-engagement system..."
    );

    // 24 hours ago
    const inactiveTime =
      new Date(
        Date.now() - 24 * 60 * 60 * 1000
      );

    // =========================
    // FIND INACTIVE USERS
    // =========================
    const users = await User.find({

      lastActive: {
        $lte: inactiveTime
      },

      email: {
        $exists: true,
        $nin: ["", null]
      }

    })

    .select(
      "email fullName username lastReEngagementEmail"
     )

    // LIMIT USERS PER RUN
    .limit(15);

    console.log(
      `${users.length} inactive users found`
    );

    for (const user of users) {

      try {

        // =========================
        // PREVENT SPAM
        // =========================
        if (
          user.lastReEngagementEmail &&
          (
            Date.now() -
            new Date(
              user.lastReEngagementEmail
            ).getTime()
          ) < 24 * 60 * 60 * 1000
        ) {

          continue;

        }

        // =========================
        // SKIP INVALID EMAIL
        // =========================
        if (!user.email) {
          continue;
        }

        // =========================
        // SEND EMAIL
        // =========================
        await sendEmail({

          to: user.email,

          subject:
            "You’re missing out on Afrisocial 🌍",

          html: `
            <div style="
              font-family: Arial;
              padding: 20px;
            ">

              <h2>
                Hey ${user.fullName || user.username},
              </h2>

              <p>
                New posts, Vybze videos,
                battle polls and trending
                African conversations are
                happening right now check it out!.
              </p>

              <a
                href="https://afrisocial.com.ng/feed.html"
                style="
                  display:inline-block;
                  background:#16a34a;
                  color:white;
                  padding:12px 20px;
                  text-decoration:none;
                  border-radius:8px;
                  margin-top:15px;
                "
              >
                Open Afrisocial
              </a>

            </div>
          `

        });

        // =========================
        // SAVE LAST EMAIL TIME
        // =========================
        user.lastReEngagementEmail =
          new Date();

        await user.save();

        console.log(
          `Re-engagement sent to ${user.email}`
        );

        // =========================
        // PREVENT SERVER OVERLOAD
        // =========================
        await delay(1500);

      } catch (err) {

        console.error(
          `EMAIL ERROR (${user.email}):`,
          err.message
        );

      }

    }

  } catch (err) {

    console.error(
      "RE-ENGAGEMENT ERROR:",
      err
    );

  }

};
