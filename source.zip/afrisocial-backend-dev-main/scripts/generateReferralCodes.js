const mongoose = require("mongoose");
const User = require("../models/User");

require("dotenv").config();

function generateReferralCode(username) {
  const random =
    Math.floor(1000 + Math.random() * 9000);

  return `${username}${random}`;
}

async function run() {
  try {

    await mongoose.connect(process.env.MONGO_URI);

    console.log("MongoDB connected");

    const users = await User.find({
      $or: [
        { referralCode: { $exists: false } },
        { referralCode: "" },
        { referralCode: null }
      ]
    });

    console.log(
      `Found ${users.length} users without referral codes`
    );

    for (const user of users) {

      let code;
      let exists = true;

      // make sure code is unique
      while (exists) {

        code =
          generateReferralCode(user.username);

        exists = await User.findOne({
          referralCode: code
        });
      }

      user.referralCode = code;

      await user.save();

      console.log(
        `Generated code for ${user.username}: ${code}`
      );
    }

    console.log("Done generating referral codes");

    process.exit();

  } catch (err) {

    console.error(err);

    process.exit(1);
  }
}

run();
