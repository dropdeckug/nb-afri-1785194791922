const express        = require('express');
const router         = express.Router();
const auth           = require('../middleware/auth');
const Post           = require('../models/Post');
const User           = require('../models/User'); 
const ModerationLog  = require('../models/ModerationLog'); 
const { sendPushNotification } = require("../controllers/notificationController");

// ==========================================
// 🔒 SECURE MASTER GATEWAY (DATABASE-INDEPENDENT)
// ==========================================

// Independent admin gateway validator (Reads directly from Render host environment)
router.post('/admin/gateway-verify', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    const trueEmail = process.env.MASTER_ADMIN_EMAIL;
    const truePassword = process.env.MASTER_ADMIN_PASSWORD;

    // Safety fallback: Prompts you if you haven't typed your variables into Render yet
    if (!trueEmail || !truePassword) {
      return res.status(500).json({ 
        success: false, 
        message: "System environment credentials not configured on the host server." 
      });
    }

    if (email === trueEmail && password === truePassword) {
      // Returns the dedicated verification token to pass security-check middleware handles
      return res.status(200).json({ 
        success: true, 
        masterKey: "Afrisocial_Master_Admin_Secret_Key_Token" 
      });
    }

    return res.status(401).json({ success: false, message: "Invalid master credentials." });
  } catch (err) {
    console.error('Gateway Verify error:', err);
    return res.status(500).json({ success: false, message: "Server gateway execution error." });
  }
});

// ==========================================
// EXISTING AUTOMATED / USER PATHWAYS
// ==========================================

// Auto-flag route
router.post('/flag', auth, async (req, res) => {
  try {
    const { content, contentType, reasons, severity, action } = req.body; 

    await ModerationLog.create({
      userId: req.user.userId,
      content, contentType, reasons, severity, action
    }); 

    // Send push notification if severe
    if (severity === 'severe') {
      const messages = {
        hate_speech:    'Your post was removed for hate speech.',
        malicious_link: 'Your post was removed for a malicious link.',
        profanity:      'Your post was removed for inappropriate language.',
        spam_pattern:   'Your post was removed for spam.',
      };
      const body = messages[reasons[0]] ||
        'Your post violated our community guidelines.'; 

     await sendPushNotification(req.user.userId, { // Adjusted to match your middleware token key
       title: "⚠️ Content Removed",
       body,
       click_action: "/notification.html",
       icon: "/uploads/images/africa.png"
     });
    } 

    res.status(200).json({ ok: true });
  } catch (err) {
    console.error('Flag error:', err);
    res.status(500).json({ message: 'Server error' });
  }
}); 

// User report route
router.post('/report', auth, async (req, res) => {
  try {
    const { contentId, contentType, reason } = req.body; 

    await ModerationLog.create({
      userId:      req.user.userId,
      contentId,
      contentType,
      reasons:     [reason],
      severity:    'mild',
      action:      'user_report',
    }); 

    // Auto-remove if 5+ reports
    const count = await ModerationLog.countDocuments({
      contentId,
      action: 'user_report'
    }); 

    if (count >= 5) {
      // Switch from findByIdAndDelete to a soft delete to protect data
      await Post.findByIdAndUpdate(contentId, {
        isDeleted: true,
        moderationStatus: 'under_review',
        moderatedAt: new Date(),
        moderationReason: 'Auto-hidden due to community reports.'
      });
    } 

    res.status(200).json({ ok: true });
  } catch (err) {
    console.error('Report error:', err);
    res.status(500).json({ message: 'Server error' });
  }
}); 

// Admin — view all flagged content (Kept original route intact)
router.get('/admin/flagged', auth, async (req, res) => {
  try {
    const logs = await ModerationLog.find({ status: 'pending' })
      .populate('userId', 'username email')
      .sort({ createdAt: -1 })
      .limit(50);
    res.status(200).json({ logs });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
}); 


// ==========================================
// NEW ADMIN CONTENT MODERATION PIPELINE
// ==========================================

// 1. Queue 1: Get all active platform posts for live feed monitoring
router.get('/admin/queue/main', auth, async (req, res) => {
  try {
    const posts = await Post.find({ isDeleted: false })
      .populate('user', 'username fullName email profilePicture role accountStatus')
      .sort({ createdAt: -1 });

    res.status(200).json({ success: true, posts });
  } catch (err) {
    console.error('Main queue error:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

// 2. Queue 2: Get all soft-deleted posts waiting for an admin's final decision
router.get('/admin/queue/review', auth, async (req, res) => {
  try {
    const posts = await Post.find({ isDeleted: true, moderationStatus: 'under_review' })
      .populate('user', 'username fullName email profilePicture role accountStatus')
      .sort({ moderatedAt: -1 });

    res.status(200).json({ success: true, posts });
  } catch (err) {
    console.error('Review queue error:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

// 3. Action: Soft delete an active post from the feed (Moves it to Queue 2)
router.put('/admin/post/:postId/soft-delete', auth, async (req, res) => {
  try {
    const { postId } = req.params;
    const { reason } = req.body;

    const updatedPost = await Post.findByIdAndUpdate(
      postId,
      {
        isDeleted: true,
        moderationStatus: 'under_review',
        moderatedAt: new Date(),
        moderationReason: reason || 'Content violates community guidelines.'
      },
      { new: true }
    );

    if (!updatedPost) {
      return res.status(404).json({ message: 'Post not found' });
    }

    // Log the action to your existing ModerationLog collection
    await ModerationLog.create({
      userId: req.user ? req.user.userId : null, // Safely handles master bypass payload parameters
      contentId: postId,
      contentType: 'post',
      reasons: [reason || 'Manual Soft Delete'],
      severity: 'moderate',
      action: 'soft_delete_feed'
    });

    res.status(200).json({ success: true, message: 'Post soft-deleted.' });
  } catch (err) {
    console.error('Soft delete error:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

// 4. Action: Final Judgment from Review Queue (Restore post or Restrict user)
router.put('/admin/post/:postId/final-decision', auth, async (req, res) => {
  try {
    const { postId } = req.params;
    const { action, reason } = req.body; // Expects 'restore', 'suspend', or 'terminate'

    const post = await Post.findById(postId);
    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }

    if (action === 'restore') {
      await Post.findByIdAndUpdate(postId, {
        isDeleted: false,
        moderationStatus: 'approved',
        moderationReason: null
      });
      return res.status(200).json({ success: true, message: 'Post restored back to live feed.' });
    }

    if (action === 'suspend' || action === 'terminate') {
      const finalAccountStatus = action === 'suspend' ? 'suspended' : 'terminated';

      // Restrict user profile account
      await User.findByIdAndUpdate(post.user, {
        accountStatus: finalAccountStatus,
        statusReason: reason || `Account restricted by administration team.`,
        restrictedAt: new Date()
      });

      // Confirm post status change
      await Post.findByIdAndUpdate(postId, {
        moderationStatus: 'flagged'
      });

      // Log judgment action details inside ModerationLog
      await ModerationLog.create({
        userId: req.user ? req.user.userId : null, // Safely handles master bypass payload parameters
        contentId: postId,
        contentType: 'post',
        reasons: [reason || `User account ${finalAccountStatus}`],
        severity: 'severe',
        action: `user_${finalAccountStatus}`
      });

      return res.status(200).json({ success: true, message: `Account has been successfully ${finalAccountStatus}.` });
    }

    res.status(400).json({ message: 'Invalid moderation action parameter.' });
  } catch (err) {
    console.error('Final decision error:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
