const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");
const notificationController = require("../controllers/notificationController");

// Get all notifications for logged-in user
router.get("/", auth, notificationController.getNotifications);

// Unread notification count
router.get("/unread-count", auth, notificationController.getUnreadCount);

// Mark a notification as read
router.post("/mark-read", auth, notificationController.markAllAsRead);

// Save push notification subscription
router.post("/subscribe", auth, notificationController.saveSubscription);

module.exports = router;
