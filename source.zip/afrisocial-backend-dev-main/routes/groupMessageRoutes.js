const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");
const upload = require("../middleware/upload");

const g = require("../controllers/groupMessageController");

// list groups (inbox)
router.get("/groups", auth, g.listMyGroups);

// create
router.post("/groups", auth, g.createGroup);

// single group
router.get   ("/groups/:groupId", auth, g.getGroup);
router.put   ("/groups/:groupId", auth, g.updateGroup);
router.delete("/groups/:groupId", auth, g.deleteGroup);

// members
router.get   ("/groups/:groupId/members",            auth, g.getMembers);
router.post  ("/groups/:groupId/members",            auth, g.addMembers);
router.delete("/groups/:groupId/members/:memberId",  auth, g.removeMember);
router.post  ("/groups/:groupId/leave",              auth, g.leaveGroup);

// photo
router.post("/groups/:groupId/photo", auth, upload.single("file"), g.updateGroupPhoto);

// archive / clear
router.post  ("/groups/:groupId/archive",   auth, g.archiveGroup);
router.post  ("/groups/:groupId/unarchive", auth, g.unarchiveGroup);
router.delete("/groups/:groupId/clear",     auth, g.clearGroup);

// messages
router.post("/groups/:groupId",          auth, g.sendGroupMessage);
router.get ("/groups/:groupId/messages", auth, g.getGroupMessages);

module.exports = router;
