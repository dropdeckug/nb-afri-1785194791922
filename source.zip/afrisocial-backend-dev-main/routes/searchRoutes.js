const express = require("express");
const router = express.Router();
const optionalAuth = require("../middleware/optionalAuth");

const searchController = require("../controllers/searchController");

router.get("/", optionalAuth, searchController.search);

module.exports = router;
