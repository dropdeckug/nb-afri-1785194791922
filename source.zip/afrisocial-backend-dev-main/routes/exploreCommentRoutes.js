const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");

const {
  createComment, 
  getComments 
} = require("../controllers/exploreCommentController");


// ======================
//  GET  COMMENT 
// ======================
router.get("/:postId", getComments);
// ======================
//  CREATE COMMENT / REPLY
// ======================
router.post("/:postId", auth, createComment);


module.exports = router;
