const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");
const commentController = require("../controllers/commentController");

// Create comment
router.post("/:postId", auth, commentController.createComment);

// Get comments for a post
router.get("/:postId", auth, commentController.getPostComments);

// Like / Unlike comment
router.post("/like/:commentId", auth, commentController.likeComment);

// Reply to comment
router.post("/reply/:commentId", auth, commentController.replyComment);


module.exports = router;

