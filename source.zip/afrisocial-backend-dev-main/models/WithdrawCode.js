const mongoose =
  require("mongoose");

const withdrawCodeSchema =
  new mongoose.Schema({

    user: {
      type:
        mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true
    },

    email: {
      type: String,
      required: true
    },

    code: {
      type: String,
      required: true
    },

    expiresAt: {
      type: Date,
      required: true
    }

  },

  {
    timestamps: true
  }

);

module.exports =
  mongoose.model(
    "WithdrawCode",
    withdrawCodeSchema
  );
