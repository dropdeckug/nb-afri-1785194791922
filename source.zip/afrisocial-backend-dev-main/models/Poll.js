const mongoose = require("mongoose");

const pollOptionSchema = new mongoose.Schema({
  text: String,
  image: String,
  votes: { type: Number, default: 0 }
});

const pollSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  question: { type: String, required: true },

  options: [pollOptionSchema],

  voters: [
    {
      user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
      optionId: String
    }
  ],

  respondCount: { type: Number, default: 0 },

  reactions: {
    type: [
      {
        user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
        emoji: String
      }
    ],
    default: []
  }

}, { timestamps: true });

module.exports = mongoose.model("Poll", pollSchema);
