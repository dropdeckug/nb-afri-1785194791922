const mongoose = require("mongoose");

const referralSchema = new mongoose.Schema({

  referrer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true
  },

  referredUser: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true
  },

  earnings: {
    type: Number,
    default: 0
  },

  isActive: {
    type: Boolean,
    default: false
  },

  activatedAt: {
    type: Date,
    default: null
  }

}, {
  timestamps: true
});

module.exports =
  mongoose.model(
    "Referral",
    referralSchema
  );
