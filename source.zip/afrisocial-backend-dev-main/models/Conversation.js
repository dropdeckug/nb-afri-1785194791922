const mongoose = require("mongoose");

const conversationSchema = new mongoose.Schema(
  {
    participants: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        required: true
      }
    ],
    lastMessage:   { type: String, default: "" },
    lastMessageAt: { type: Date },

    // per-user inbox state
    archivedBy: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
    clearedBy:  [{
      user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
      at:   { type: Date, default: Date.now }
    }]
  },
  { timestamps: true }
);

module.exports = mongoose.model("Conversation", conversationSchema);
