const mongoose = require("mongoose");

const postSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true
    },

    text: {
      type: String,
      trim: true
    },

    images: [
      {
        type: String 
      }
    ],

    video: {
      type: String 
    },

    videoThumbnail: {
      type: String,
      default: ""
    },

    views: {
      type: Number,
      default: 0
    },

    viewedBy: [ 
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
      }
    ],

    likes: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
      }
    ],

    stars: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
      }
    ], 

    hashtags: [
      {
        type: String,
        trim: true,
        lowercase: true, 
        index: true
      }
    ], 
    mentions: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
      }
    ], 

    isBirthdayPost: {
       type: Boolean,
       default: false
    },

    birthdayFor: {
       type: mongoose.Schema.Types.ObjectId,
       ref: "User",
       default: null
     },
    // ════════════════════════════════
    // SPONSORED POSTS / ADS
    // ════════════════════════════════

    isSponsored: {
      type: Boolean,
      default: false
    },

    sponsoredLabel: {
      type: String,
      default: "Sponsored"
    },

    sponsorName: {
      type: String,
      trim: true,
      default: ""
    },

    redirectUrl: {
      type: String,
      trim: true,
      default: ""
    },

    ctaText: {
      type: String,
      trim: true,
      default: "Learn More"
    },

    impressions: {
      type: Number,
      default: 0
    },

    clicks: {
      type: Number,
      default: 0
    },

    expiresAt: {
      type: Date,
      default: null
    },

    // ════════════════════════════════
    // CONTENT MODERATION EXTENSIONS
    // ════════════════════════════════
    isDeleted: { 
      type: Boolean, 
      default: false, 
      index: true 
    },
    moderationStatus: { 
      type: String, 
      enum: ['approved', 'under_review', 'flagged'], 
      default: 'approved', 
      index: true 
    },
    moderatedAt: { 
      type: Date 
    },
    moderationReason: { 
      type: String 
    }
    
  },
  { timestamps: true }
);

postSchema.index({
  text: "text",
  hashtags: "text"
});

module.exports = mongoose.model("Post", postSchema);
