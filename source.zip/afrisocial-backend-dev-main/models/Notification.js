const mongoose = require("mongoose");

const notificationSchema = new mongoose.Schema(
  {
    recipient: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true
    },
    sender: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true
    },
    type: {
      type: String,
      enum: [
        "like",
        "comment",
        "reply", 
        "star",
        "gift",
        "birthday",
        "follow",
        "follow_back", 
        "message", 
        "poll",
        "poll_vote",
        "poll_react",
        "poll_response", 
        "mention" 
      ],
      required: true
    },
    content: {
       type: String,
       trim: true
     },
    post: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Post"
    },
    comment: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Comment"
    },
    poll: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Poll"
    },
    isRead: {
      type: Boolean,
      default: false
    }
  },
  { timestamps: true }
);


module.exports = mongoose.model("Notification", notificationSchema);
