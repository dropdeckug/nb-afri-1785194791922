const mongoose = require("mongoose");

const explorePostSchema = new mongoose.Schema(
{
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true
  },

  // ══════════════════════════════════════════════
  // CONTENT
  // ══════════════════════════════════════════════
  title: {
    type: String,
    trim: true
  },

  text: {
    type: String,
    trim: true
  },

  // ══════════════════════════════════════════════
  // MEDIA
  // ══════════════════════════════════════════════
  images: [String],
  video: String,

  // ══════════════════════════════════════════════
  // TYPE
  // ══════════════════════════════════════════════
  isQuestion: {
    type: Boolean,
    default: false
  },

  // ══════════════════════════════════════════════
  // ORGANIZATION
  // ══════════════════════════════════════════════
  category: {
    type: String,
    enum: [
      "culture","politics","technology","history",
      "business","entertainment","education",
      "sports","religion","news","agriculture"
    ]
  },

  region: {
    type: String,
    enum: [
      "West Africa","East Africa","North Africa",
      "South Africa","Central Africa","Africa"
    ]
  },

  // ══════════════════════════════════════════════
  // ENGAGEMENT COUNTS
  // ══════════════════════════════════════════════
  likeCount: {
    type: Number,
    default: 0
  },

  starCount: {
    type: Number,
    default: 0
  },

  commentCount: {
    type: Number,
    default: 0
  },

  upvoteCount: {
    type: Number,
    default: 0
  },

  downvoteCount: {
    type: Number,
    default: 0
  },

  viewCount: {
    type: Number,
    default: 0
  },

  // ══════════════════════════════════════════════
  // USER INTERACTIONS
  // ══════════════════════════════════════════════
  likedBy: [
    { type: mongoose.Schema.Types.ObjectId, ref: "User" }
  ],

  starredBy: [
    { type: mongoose.Schema.Types.ObjectId, ref: "User" }
  ],

  upvotedBy: [
    { type: mongoose.Schema.Types.ObjectId, ref: "User" }
  ],

  downvotedBy: [
    { type: mongoose.Schema.Types.ObjectId, ref: "User" }
  ],

  viewedBy: [
    { type: mongoose.Schema.Types.ObjectId, ref: "User" }
  ],

  // ══════════════════════════════════════════════
  // RANKING SYSTEM
  // ══════════════════════════════════════════════
  score: {
    type: Number,
    default: 0
  },

  hotScore: {
    type: Number,
    default: 0
  },

  // ══════════════════════════════════════════════
  // QUESTION SYSTEM
  // ══════════════════════════════════════════════
  answerCount: {
    type: Number,
    default: 0
  },

  // ══════════════════════════════════════════════
  // MODERATION
  // ══════════════════════════════════════════════
  isDeleted: {
    type: Boolean,
    default: false
  }

},
{ timestamps: true }
);

// ══════════════════════════════════════════════
// INDEXES (VERY IMPORTANT FOR PERFORMANCE)
// ══════════════════════════════════════════════
explorePostSchema.index({ hotScore: -1 });     // trending
explorePostSchema.index({ score: -1 });        // top
explorePostSchema.index({ createdAt: -1 });    // latest
explorePostSchema.index({ category: 1 });
explorePostSchema.index({ region: 1 });

module.exports = mongoose.model("ExplorePost", explorePostSchema);
