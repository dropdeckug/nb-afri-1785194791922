// server.js
const express = require("express");
const dotenv = require("dotenv");
const cors = require("cors");
const connectDB = require("./config/db");
const updateLastActive = require("./middleware/updateLastActive");

// Load environment variables first
dotenv.config();

// Connect to MongoDB
connectDB();

const app = express();

// Middlewares
// CORS allow-list for frontends that are allowed to call this API.
// Add any new deployed frontend URL here, or set FRONTEND_URLS as a comma-separated env var.
const allowedOrigins = new Set([
  "http://localhost:3000",
  "http://localhost:2435",
  "http://localhost:5173",
  "http://localhost:8080",
  "https://afrisocial.com.ng",
  "https://www.afrisocial.com.ng",
  "https://afrisocial.netlify.app",
  "https://afrisocial-backend.onrender.com",
  ...(process.env.FRONTEND_URLS || "")
    .split(",")
    .map((origin) => origin.trim())
    .filter(Boolean),
]);

const allowedOriginPatterns = [
  /^https?:\/\/localhost(?::\d+)?$/i,
  /^https?:\/\/127\.0\.0\.1(?::\d+)?$/i,
  /^https:\/\/.*\.lovable\.app$/i,
  /^https:\/\/.*\.lovableproject\.com$/i,
  /^https:\/\/.*\.lovable\.dev$/i,
  /^https:\/\/([a-z0-9-]+\.)?afrisocial\.[a-z.]+$/i,
];

function isAllowedOrigin(origin) {
  if (!origin) return true; // curl / native apps / same-origin
  return allowedOrigins.has(origin) || allowedOriginPatterns.some((pattern) => pattern.test(origin));
}

const corsOptions = {
  origin(origin, cb) {
    if (isAllowedOrigin(origin)) return cb(null, true);
    console.warn("CORS blocked:", origin);
    return cb(null, false);
  },
  credentials: true,
  methods: ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization", "X-Requested-With", "Accept", "Origin"],
  optionsSuccessStatus: 204,
};
app.use(cors(corsOptions));
app.options(/.*/, cors(corsOptions));


// body parses (only define ones - with limit) 
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

app.use(
  "/uploads/thumbnails",
  express.static("uploads/thumbnails")
);

// last active update
app.use(updateLastActive);

// debug logger 
app.use((req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  next();
});

// Routes
const userRoutes = require("./routes/userRoutes");
app.use("/api/users", userRoutes);

const postRoutes = require("./routes/postRoutes");
app.use("/api/posts", postRoutes);

// Group routes MUST mount first — messageRoutes has a catch-all `GET /:conversationId`
app.use("/api/messages", require("./routes/groupMessageRoutes"));
app.use("/api/messages", require("./routes/messageRoutes"));

app.use("/api/explore", require("./routes/exploreRoutes"));

app.use("/api/comments", require("./routes/commentRoutes"));

app.use("/api/notifications", require("./routes/notificationRoutes"));

app.use("/api/explore/comments", require("./routes/exploreCommentRoutes"));

// story routes 
const storyRoutes = require("./routes/storyRoutes");
app.use("/api/stories", storyRoutes);

// moderation routes 
const moderationRoutes = require('./routes/moderation');
app.use('/api/moderation', moderationRoutes);

// analytics routes
const analyticsRoutes = require("./routes/analyticsRoutes");
app.use("/api/analytics", analyticsRoutes);

// Vybze routes 
const vybzeRoutes = require("./routes/vybzeRoutes");
app.use("/api/vybze", vybzeRoutes);

// feedback routes
const feedbackRoutes = require("./routes/feedbackRoutes");
app.use("/api/feedback", feedbackRoutes);

// Google auth 
const authRoutes = require('./routes/auth');
app.use('/api/auth', authRoutes);

// waitlist routes
const waitlistRoutes = require("./routes/waitlistRoutes");
app.use("/api/waitlist", waitlistRoutes);

// poll routes 
const pollRoutes = require("./routes/pollRoutes");
app.use("/api/polls", pollRoutes);

// session routes 
const sessionRoutes = require("./routes/sessionRoutes");
app.use("/api/session", sessionRoutes);


// wallet routes 
app.use(
  "/api/wallet",
  require("./routes/walletRoutes")
);

// Referral routes 
app.use(
  "/api/referral",
  require("./routes/referralRoutes")
);


// Search routes 
const searchRoutes = require("./routes/searchRoutes");
app.use("/api/search", searchRoutes);


// Seo routes 
const seoRoutes = require("./routes/seoRoutes");
app.use("/", seoRoutes);

// Sitemap routes 
const sitemapRoutes = require("./routes/sitemapRoutes");
app.use("/", sitemapRoutes);

// Robot routes 
const robotsRoutes = require("./routes/robotsRoutes");
app.use("/", robotsRoutes);






// global error handler 
app.use((err, req, res, next) => {
  console.error("GLOBAL ERROR:", err);
  res.status(500).json({ message: err.message });
});

require("./cron/reEngagementCron");

require("./utils/birthdayCron");

// Start server (HTTP + Socket.IO)
const PORT = process.env.PORT || 3000;
const http = require("http");
const server = http.createServer(app);

// Socket.IO — real-time messaging, typing, read receipts, calls (WebRTC signaling)
try {
  const { Server } = require("socket.io");
  const jwt = require("jsonwebtoken");
  const User = require("./models/User");
  const Group = require("./models/Group");

  const io = new Server(server, {
    cors: {
      origin(origin, cb) {
        if (isAllowedOrigin(origin)) return cb(null, true);
        console.warn("Socket.IO CORS blocked:", origin);
        return cb(null, false);
      },
      credentials: true
    },
    pingTimeout: 60000
  });

  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth?.token
                 || (socket.handshake.headers.authorization || "").replace(/^Bearer\s+/i, "");
      if (!token) return next(new Error("No token"));
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const user = await User.findById(decoded.userId).select("_id fullName username");
      if (!user) return next(new Error("Bad token"));
      socket.userId = user._id.toString();
      socket.user = user;
      next();
    } catch (e) { next(new Error("Unauthorized")); }
  });

  io.on("connection", async (socket) => {
    socket.join(`user:${socket.userId}`);
    try {
      const groups = await Group.find({ members: socket.userId }).select("_id");
      groups.forEach(g => socket.join(`group:${g._id}`));
    } catch (_) {}
    io.emit("presence:online", { userId: socket.userId });

    socket.on("conversation:join",  (id) => id && socket.join(`conversation:${id}`));
    socket.on("conversation:leave", (id) => id && socket.leave(`conversation:${id}`));
    socket.on("group:join",         (id) => id && socket.join(`group:${id}`));
    socket.on("group:leave",        (id) => id && socket.leave(`group:${id}`));

    socket.on("typing:start", ({ conversationId, to }) => {
      if (to) io.to(`user:${to}`).emit("typing:start", { conversationId, from: socket.userId });
    });
    socket.on("typing:stop", ({ conversationId, to }) => {
      if (to) io.to(`user:${to}`).emit("typing:stop", { conversationId, from: socket.userId });
    });

    // WebRTC signaling (1-on-1 audio/video)
    socket.on("call:invite", ({ to, type, sdp, callId }) => {
      if (to) io.to(`user:${to}`).emit("call:invite", {
        from: socket.userId, fromUser: socket.user, type, sdp, callId
      });
    });
    socket.on("call:answer", ({ to, sdp, callId }) => {
      if (to) io.to(`user:${to}`).emit("call:answer", { from: socket.userId, sdp, callId });
    });
    socket.on("call:ice", ({ to, candidate, callId }) => {
      if (to) io.to(`user:${to}`).emit("call:ice", { from: socket.userId, candidate, callId });
    });
    socket.on("call:reject", ({ to, callId }) => {
      if (to) io.to(`user:${to}`).emit("call:reject", { from: socket.userId, callId });
    });
    socket.on("call:end", ({ to, callId }) => {
      if (to) io.to(`user:${to}`).emit("call:end", { from: socket.userId, callId });
    });

    socket.on("disconnect", () => {
      io.emit("presence:offline", { userId: socket.userId });
    });
  });

  app.set("io", io);
  console.log("[socket.io] real-time enabled");
} catch (e) {
  console.warn("[socket.io] not enabled (install `socket.io`):", e.message);
}

server.listen(PORT, () => console.log(`Server running on port ${PORT}`));







