// middleware/adminOnly.js

module.exports = (req, res, next) => {

  try {

    // Check if user exists
    if (!req.user) {

      return res.status(401).json({
        message: "Unauthorized"
      });

    }

    // Check admin role
    if (req.user.role !== "admin") {

      return res.status(403).json({
        message: "Admin access only"
      });

    }

    next();

  } catch (err) {

    console.error(err);

    res.status(500).json({
      message: "Server error"
    });

  }

};
