const jwt = require("jsonwebtoken");
const User = require("../models/User");

module.exports = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ message: "No token provided" });
    }

    const token = authHeader.split(" ")[1];

    // 🌟 THE INDEPENDENT MASTER BYPASS RULE
    // If the token matches our environment-validated master key, skip database lookups entirely.
    if (token === "Afrisocial_Master_Admin_Secret_Key_Token") {
      req.user = { 
        _id: null, 
        userId: null, 
        role: "admin", 
        isMasterKey: true 
      };
      return next(); // Let the master admin right through!
    }

    // ==========================================
    // STANDARD USER JWT VERIFICATION PATHWAY
    // ==========================================
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const user = await User.findById(decoded.userId).select("-password");

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Normalize the authenticated user id shape.  Some older controllers use
    // req.user.id while newer message code uses req.user._id; keep both valid.
    req.user = user;
    req.user.id = user._id.toString();
    req.user.userId = user._id.toString();
    next();

  } catch (err) {
    return res.status(401).json({ message: "Invalid token" });
  }
};
