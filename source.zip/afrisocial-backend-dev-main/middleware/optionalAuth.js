const jwt = require("jsonwebtoken");
const User = require("../models/User");

const optionalAuth = async (req, res, next) => {
  try {

    const authHeader = req.headers.authorization;

    if (
      !authHeader ||
      !authHeader.startsWith("Bearer ")
    ) {
      return next();
    }

    const token = authHeader.split(" ")[1];

    const decoded = jwt.verify(
      token,
      process.env.JWT_SECRET
    );

    const userId = decoded.userId || decoded.id || decoded._id || decoded.sub;
    const user = userId ? await User.findById(userId) : null;

    if (user) {
      req.user = user;
      req.user.id = user._id.toString();
      req.user.userId = user._id.toString();
    }

    next();

  } catch (err) {

    console.log(
      "OPTIONAL AUTH SKIPPED:",
      err.message
    );

    next();

  }
};

module.exports = optionalAuth;
