const bcrypt = require("bcryptjs");

const Wallet =
  require("../models/Wallet");

const WalletTransaction =
  require("../models/WalletTransaction");

const User =
  require("../models/User");

const WithdrawCode =
  require("../models/WithdrawCode");

const axios = require("axios");

const sendEmail =
  require("../utils/sendEmail");

const Comment =
  require("../models/Comment");

const Notification = 
  require("../models/Notification");

const { sendPushNotification } = 
  require("./notificationController");

const Post = 
  require("../models/Post");




exports.getWallet = async (req, res) => {
  try {

    let wallet =
      await Wallet.findOne({
        user: req.user.id
      });

    if (!wallet) {
      wallet = await Wallet.create({
        user: req.user.id
      });
    }

    const transactions =
      await WalletTransaction.find({
        user: req.user.id
      })
      .sort({ createdAt: -1 })
      .limit(50);

    res.json({
      availableBalance:
        wallet.availableBalance,

      starBalance:
        wallet.starBalance,

      pendingBalance:
        wallet.pendingBalance,

      totalEarned:
        wallet.totalEarned,

      currency:
        wallet.currency,

      hasPin:
        !!wallet.walletPin,

      transactions
    });

  } catch (err) {

    console.error(err);

    res.status(500).json({
      message: "Failed to load wallet"
    });

  }
};





exports.createWalletPin = async (req, res) => {

  try {

    const { pin } = req.body;

    // Validate PIN
    if (!pin || pin.length !== 4) {

      return res.status(400).json({
        message: "PIN must be 4 digits"
      });

    }

    // Find wallet
    let wallet =
      await Wallet.findOne({
        user: req.user.id
      });

    // Create wallet if missing
    if (!wallet) {

      wallet = await Wallet.create({
        user: req.user.id
      });

    }

    // Prevent changing existing PIN
    if (wallet.walletPin) {

      return res.status(400).json({
        message: "Wallet PIN already exists"
      });

    }

    // Hash PIN
    const hashedPin =
      await bcrypt.hash(pin, 10);

    // Save PIN
    wallet.walletPin = hashedPin;

    await wallet.save();

    res.json({
      success: true,
      message: "Wallet PIN created"
    });

  } catch (err) {

    console.error(err);

    res.status(500).json({
      message: "Failed to create wallet PIN"
    });

  }

};





exports.initializeRecharge =
  async (req, res) => {

  try {

    const {
      stars,
      amount,
      pin
    } = req.body;

    // ─────────────────────────────
    // FIND USER WALLET
    // ─────────────────────────────
    const wallet =
      await Wallet.findOne({
        user: req.user.id
      });

    if (!wallet) {

      return res.status(404).json({
        message: "Wallet not found"
      });

    }

    // ─────────────────────────────
    // VERIFY PIN
    // ─────────────────────────────
    const isMatch =
      await bcrypt.compare(
        pin.toString(),
        wallet.walletPin
      );

    if (!isMatch) {

      return res.status(400).json({
        message: "Invalid wallet PIN"
      });

    }

    // ─────────────────────────────
    // FIND USER
    // ─────────────────────────────
    const user =
      await User.findById(req.user.id);

    const txRef =
      `AFRI-${Date.now()}`;

    // Flutterwave request
    const response = await axios.post(

      "https://api.flutterwave.com/v3/payments",

      {

        tx_ref: txRef,

        amount,

        currency: "NGN",

        redirect_url:
          "https://afrisocial.com.ng/wallet-success.html",

        customer: {

          email: user.email,

          name: user.username

        },

        customizations: {

          title:
            "Afrisocial Wallet Recharge",

          description:
            `${stars} Stars Purchase`

        }, 

       meta: {

         stars,

         userId: req.user.id

        }, 

      },

      {

        headers: {

          Authorization:
            `Bearer ${process.env.FLW_SECRET_KEY}`,

          "Content-Type":
            "application/json"

        }

      }

    );
    

    res.json({

      success: true,

      link:
        response.data.data.link

    });

  } catch (err) {

    console.error(
      err.response?.data || err
    );

    res.status(500).json({

      message:
        "Failed to initialize payment"

    });

  }
};






exports.verifyRecharge =
  async (req, res) => {

  try {

    const { transaction_id } = req.query;

    const response =
      await axios.get(

        `https://api.flutterwave.com/v3/transactions/${transaction_id}/verify`,

        {
          headers: {
            Authorization:
              `Bearer ${process.env.FLW_SECRET_KEY}`
          }
        }

      );

    const data =
      response.data.data;

    if (data.status !== "successful") {
      return res.status(400).json({
        message: "Payment failed"
      });
    }

    const txRef =
      data.tx_ref;

// Prevent duplicate recharge
const existingTransaction =
  await WalletTransaction.findOne({
    reference: txRef,
    status: "completed"
  });

if (existingTransaction) {

  return res.json({
    success: true
  });

}

    // Prevent double credit
    if (!data.meta?.stars) {

  return res.status(400).json({
    message: "Invalid payment metadata"
  });

}

    // Security checks

    if (data.currency !== "NGN") {
      return res.status(400).json({
        message:
          "Invalid currency"
      });
    }

    

    const wallet =
    await Wallet.findOne({
    user: data.meta.userId
  });

    if (!wallet) {
      return res.status(404).json({
        message: "Wallet not found"
      });
    }

    const stars =
   Number(
    data.meta?.stars || 0
  );

   wallet.starBalance =
  (wallet.starBalance || 0) + stars;
    
    await wallet.save();

// Create completed transaction ONLY after successful payment
await WalletTransaction.create({

  user: data.meta.userId,

  type: "recharge",

  title: `Recharge ${stars} Stars`,

  amount: stars,

  currency: "star",

  reference: txRef,

  status: "completed",

  metadata: {

    stars,

    moneyAmount:
          data.amount
  }

});
    
    res.json({
      success: true
    });

  } catch (err) {

    console.error(
      err.response?.data || err
    );

    res.status(500).json({
      message:
        "Verification failed"
    });

  }
};





exports.withdrawFunds =
  async (req, res) => {

  try {

    const {
      amount,
      bank,
      accountNumber,
      email,
      code,
      pin
    } = req.body;

    // ─────────────────────────────
    // Validate required fields
    // ─────────────────────────────
    if (
      !amount ||
      !bank ||
      !accountNumber ||
      !email ||
      !code ||
      !pin
    ) {
      return res.status(400).json({
        message: "All fields are required"
      });
    }

    // ─────────────────────────────
    // Find wallet
    // ─────────────────────────────
    const wallet =
      await Wallet.findOne({
        user: req.user.id
      });

    if (!wallet) {
      return res.status(404).json({
        message: "Wallet not found"
      });
    }

    // ─────────────────────────────
    // Verify wallet PIN
    // ─────────────────────────────
    const isMatch =
      await bcrypt.compare(
        pin,
        wallet.walletPin
      );

    if (!isMatch) {
      return res.status(400).json({
        message: "Invalid wallet PIN"
      });
    }

    // ─────────────────────────────
    // Verify withdrawal code
    // ─────────────────────────────
    const withdrawCode =
      await WithdrawCode.findOne({

        user: req.user.id,

        email,

        code

      });

    if (!withdrawCode) {
      return res.status(400).json({
        message:
          "Invalid verification code"
      });
    }

    // ─────────────────────────────
    // Check expiration
    // ─────────────────────────────
    if (
      new Date() >
      withdrawCode.expiresAt
    ) {
      return res.status(400).json({
        message:
          "Verification code expired"
      });
    }

 // ─────────────────────────────
// Minimum withdrawal
// ─────────────────────────────
if (Number(amount) < 2000) {

  return res.status(400).json({

    message:
      "Minimum withdrawal is ₦2000"

  });

}

// ─────────────────────────────
// Maximum withdrawal
// ─────────────────────────────
if (Number(amount) > 50000) {

  return res.status(400).json({

    message:
      "Maximum withdrawal exceeded"

  });

}

    // ─────────────────────────────
    // Balance check
    // ─────────────────────────────
    if (
      wallet.availableBalance <
      Number(amount)
    ) {
      return res.status(400).json({
        message:
          "Insufficient balance"
      });
    }

    // ─────────────────────────────
    // Deduct balance
    // ─────────────────────────────
   // Move money to pending balance
    wallet.availableBalance -= Number(amount);

    wallet.pendingBalance += Number(amount);

    await wallet.save(); 

    // ─────────────────────────────
    // Create transaction
    // ─────────────────────────────
    await WalletTransaction.create({

      user: req.user.id,

      type: "withdraw",

      title:
        `Withdrawal to ${bank}`,

      amount: -Number(amount),

      status: "pending",

      metadata: {

        bank,

        accountNumber,

        email, 

        withdrawalStatus: "pending"

      }

    });

    // ─────────────────────────────
    // Delete used OTP
    // ─────────────────────────────
    await WithdrawCode.deleteMany({
      user: req.user.id
    });

    // ─────────────────────────────
    // Success
    // ─────────────────────────────
    res.json({

      success: true,

      message:
        "Withdrawal submitted successfully"

    });

  } catch (err) {

    console.error(err);

    res.status(500).json({
      message: "Withdrawal failed"
    });

  }
};




exports.sendGift = async (req, res) => {
  try {

    const {
      recipient,
      amount,
      pin
    } = req.body;

    if (!recipient || !amount || !pin) {
      return res.status(400).json({
        message: "Missing required fields"
      });
    }

    const senderWallet =
      await Wallet.findOne({
        user: req.user.id
      });

    if (!senderWallet) {
      return res.status(404).json({
        message: "Wallet not found"
      });
    }

    // Verify PIN
    const isMatch = await bcrypt.compare(
      pin,
      senderWallet.walletPin
    );

    if (!isMatch) {
      return res.status(400).json({
        message: "Invalid PIN"
      });
    }

    // Find recipient
    const recipientUser =
      await User.findOne({
        $or: [
          { username: recipient },
          { email: recipient }
        ]
      });

    if (!recipientUser) {
      return res.status(404).json({
        message: "Recipient not found"
      });
    }

    // Prevent self gifting
    if (
      recipientUser._id.toString() ===
      req.user.id
    ) {
      return res.status(400).json({
        message: "You cannot gift yourself"
      });
    }

    // Balance check
    if (senderWallet.starBalance < amount) {
      return res.status(400).json({
        message: "Insufficient stars"
      });
    }

    // Recipient wallet
    let recipientWallet =
      await Wallet.findOne({
        user: recipientUser._id
      });

    if (!recipientWallet) {
      recipientWallet =
        await Wallet.create({
          user: recipientUser._id
        });
    }

    // Platform fee
    const fee =
    Math.floor(amount * 0.30);

   // Recipient gets 70%
    const recipientAmount =
    amount - fee;

   const nairaValue =
   recipientAmount * 15; 

   // Transfer
   senderWallet.starBalance -= amount;

   recipientWallet.availableBalance += nairaValue;

    await senderWallet.save();
    await recipientWallet.save();

    // Sender tx
    await WalletTransaction.create({
      user: req.user.id,
      type: "gift",
      title: `Gift sent to ${recipientUser.username}`,
      amount: -amount,
      currency: "star",
      status: "completed"
    });

    // Recipient tx
await WalletTransaction.create({
  user: recipientUser._id,
  type: "gift",
  title:  `Gift received from ${req.user.username}`,
  amount: nairaValue,
  currency: "money",
  status: "completed"
 
});

    res.json({
      success: true,
      message: "Gift sent successfully"
    });

  } catch (err) {

    console.error(err);

    res.status(500).json({
      message: "Failed to send gift"
    });

  }
};






exports.sendWithdrawCode =
  async (req, res) => {

  try {

    const { email } = req.body;

    if (!email) {
      return res.status(400).json({
        message:
          "Email is required"
      });
    }

    const code =
      Math.floor(
        100000 +
        Math.random() * 900000
      ).toString();

    // Delete old codes
    await WithdrawCode.deleteMany({
      user: req.user.id
    });

    // Save new code
    await WithdrawCode.create({

      user: req.user.id,

      email,

      code,

      expiresAt:
        new Date(
          Date.now() +
          10 * 60 * 1000
        )

    });

    // Send email
    await sendEmail({

  to: email,

  subject:
    "Afrisocial Withdrawal Verification",

  html: `

    <div style="
      font-family:sans-serif;
      padding:20px;
    ">

      <h2>
        Afrisocial Verification
      </h2>

      <p>
        Your withdrawal verification
        code is:
      </p>

      <h1>
        ${code}
      </h1>

      <p>
        This code expires in
        10 minutes.
      </p>

    </div>
  `
});
    res.json({
      success: true,
      message:
        "Verification code sent"

    });

  } catch (err) {

    console.error(err);

    res.status(500).json({
      message:
        "Failed to send code"
    });

  }
};






exports.convertToStars =
  async (req, res) => {

  try {

    const {
      amount,
      stars,
      pin
    } = req.body;

    const wallet =
      await Wallet.findOne({
        user: req.user.id
      });

    if (!wallet) {
      return res.status(404).json({
        message: "Wallet not found"
      });
    }

    // Verify PIN
    const isMatch =
    await bcrypt.compare(
    pin.toString(),
    wallet.walletPin
  );

    if (!isMatch) {
      return res.status(400).json({
        message: "Invalid PIN"
      });
    }

    // Check balance
    if (wallet.availableBalance < amount) {
      return res.status(400).json({
        message: "Insufficient balance"
      });
    }

    wallet.availableBalance -= amount;
   
    // 5% conversion fee
     const feeStars =
     Math.floor(stars * 0.05);

    const finalStars =
    stars - feeStars;

    wallet.starBalance += finalStars;
    
    await wallet.save();

    await WalletTransaction.create({

      user: req.user.id,

      type: "convert",

      title:
    `Converted to ${finalStars} stars`,
      
      amount: finalStars,

      currency: "star",

      status: "completed"

    });

    res.json({
      success: true,
      message: "Converted successfully"
    });

  } catch (err) {

    console.error(err);

    res.status(500).json({
      message: "Conversion failed"
    });

  }
};





exports.approveWithdrawal = async (req, res) => {

  try {

    const { transactionId } = req.params;

    const transaction =
      await WalletTransaction.findById(transactionId);

    if (!transaction) {

      return res.status(404).json({
        message: "Transaction not found"
      });

    }

    if (transaction.status !== "pending") {

      return res.status(400).json({
        message: "Already processed"
      });

    }

    const wallet =
      await Wallet.findOne({
        user: transaction.user
      });

    if (!wallet) {

      return res.status(404).json({
        message: "Wallet not found"
      });

    }

    const amount =
      Math.abs(transaction.amount);

    // Remove from pending
    wallet.pendingBalance -= amount;

    await wallet.save();

    transaction.status = "completed";

    transaction.metadata.withdrawalStatus =
      "approved";

    await transaction.save();

    res.json({

      success: true,

      message:
        "Withdrawal approved"

    });

  } catch (err) {

    console.error(err);

    res.status(500).json({
      message: "Approval failed"
    });

  }

};






exports.rejectWithdrawal = async (req, res) => {

  try {

    const { transactionId } = req.params;

    const transaction =
      await WalletTransaction.findById(transactionId);

    if (!transaction) {

      return res.status(404).json({
        message: "Transaction not found"
      });

    }

    if (transaction.status !== "pending") {

      return res.status(400).json({
        message: "Already processed"
      });

    }

    const wallet =
      await Wallet.findOne({
        user: transaction.user
      });

    if (!wallet) {

      return res.status(404).json({
        message: "Wallet not found"
      });

    }

    const amount =
      Math.abs(transaction.amount);

    // Return money back
    wallet.pendingBalance -= amount;

    wallet.availableBalance += amount;

    await wallet.save();

    transaction.status = "failed";

    transaction.metadata.withdrawalStatus =
      "rejected";

    await transaction.save();

    res.json({

      success: true,

      message:
        "Withdrawal rejected"

    });

  } catch (err) {

    console.error(err);

    res.status(500).json({
      message: "Rejection failed"
    });

  }

};





exports.getAllWithdrawals =
  async (req, res) => {

  try {

    const withdrawals =
      await WalletTransaction.find({

        type: "withdraw"

      })

      .populate(
        "user",
        "username fullName email profilePicture"
      )

      .sort({ createdAt: -1 });

    res.json(withdrawals);

  } catch (err) {

    console.error(err);

    res.status(500).json({
      message:
        "Failed to load withdrawals"
    });

  }

};






exports.sendVybzeGift = async (req, res) => {
  try {

    const {
      recipientId,
      amount,
      giftType, 
      postId
    } = req.body;

    if (!recipientId || !amount) {
      return res.status(400).json({
        message: "Missing required fields"
      });
    }

    // Sender wallet
    const senderWallet =
      await Wallet.findOne({
        user: req.user.id
      });

    if (!senderWallet) {
      return res.status(404).json({
        message: "Wallet not found"
      });
    }

    // Prevent self gifting
    if (recipientId === req.user.id) {
      return res.status(400).json({
        message: "You cannot gift yourself"
      });
    }

    // Balance check
    if (senderWallet.starBalance < amount) {
      return res.status(400).json({
        message: "Insufficient stars"
      });
    }

    // Recipient wallet
    let recipientWallet =
      await Wallet.findOne({
        user: recipientId
      });

    if (!recipientWallet) {
      recipientWallet =
        await Wallet.create({
          user: recipientId
        });
    }

    // 30% platform fee
    const fee =
      Math.ceil(amount * 0.30);

    // Creator receives 70%
    const creatorStars =
      amount - fee;

    // Convert to naira
    const nairaValue =
      creatorStars * 15;

    // Deduct sender stars
    senderWallet.starBalance -= amount;

    // Add creator money
    recipientWallet.availableBalance += nairaValue;

    await senderWallet.save();
    await recipientWallet.save();

    // Sender transaction
    await WalletTransaction.create({
      user: req.user.id,
      type: "gift",
      title: `Sent ${giftType} gift`,
      amount: -amount,
      currency: "star",
      status: "completed"
    });

    // Recipient transaction
    await WalletTransaction.create({
      user: recipientId,
      type: "gift",
      title: `Received ${giftType} gift`,
      amount: nairaValue,
      currency: "money",
      status: "completed"
    });

// CREATE GIFT COMMENT FOR VYBZE
let giftComment = null;

if (postId) {

  giftComment = await Comment.create({

    post: postId,

    user: req.user.id,

    text: `sent a ${giftType} gift 🎁`,

    likes: [],

    mentions: [],

    isGift: true,

    giftType,

    giftStars: amount

  });

  await giftComment.populate(
    "user",
    "username fullName username profilePicture country isVerified"
  );

  await Post.findByIdAndUpdate(
    postId,
    {
      $inc: { commentCount: 1 }
    }
  );

}

 // ═══════════════════════════════
// GIFT NOTIFICATION
// ═══════════════════════════════

await Notification.create({

  recipient: recipientId,

  sender: req.user.id,

  type: "gift",

  content:
    `${req.user.username} sent you a ${giftType} gift 🎁`, 


  metadata: {
    giftType,
    stars: Number(amount)
  }
    
});

// PUSH NOTIFICATION

const payload = {

  title: "New Gift 🎁",

  body:
    `${req.user.username} sent you a ${giftType} gift`,

  icon:  req.user.username.profilePicture,

  click_action: "/notification.html"

};

await sendPushNotification(
  recipientId,
  payload
);

    res.json({
  success: true,
  message: "Gift sent successfully",
  comment: giftComment
});

  } catch (err) {

    console.error(err);

    res.status(500).json({
      message: "Failed to send gift"
    });

  }
};








exports.sendProfileGift = async (req, res) => {

  try {

    const {
      recipient,
      amount,
      giftType,
      postId
    } = req.body;

    if (!recipient || !amount) {

      return res.status(400).json({
        message: "Missing required fields"
      });

    }

    // Prevent self gifting
    if (recipient === req.user.id) {

      return res.status(400).json({
        message: "You cannot gift yourself"
      });

    }

    // Sender wallet
    const senderWallet =
      await Wallet.findOne({
        user: req.user.id
      });

    if (!senderWallet) {

      return res.status(404).json({
        message: "Wallet not found"
      });

    }

    // Balance check
    if (
      senderWallet.starBalance <
      Number(amount)
    ) {

      return res.status(400).json({
        message: "Insufficient stars"
      });

    }

    // Recipient user
    const recipientUser =
      await User.findById(recipient);

    if (!recipientUser) {

      return res.status(404).json({
        message: "Recipient not found"
      });

    }

    // Recipient wallet
    let recipientWallet =
      await Wallet.findOne({
        user: recipient
      });

    if (!recipientWallet) {

      recipientWallet =
        await Wallet.create({
          user: recipient
        });

    }

    // Platform fee
    const fee =
      Math.floor(Number(amount) * 0.30);

    // Creator gets 70%
    const creatorStars =
      Number(amount) - fee;

    // Convert to naira
    const nairaValue =
      creatorStars * 15;

    // Deduct sender stars
    senderWallet.starBalance -=
      Number(amount);

    // Add money to recipient
    recipientWallet.availableBalance +=
      nairaValue;

    await senderWallet.save();
    await recipientWallet.save();

    // Sender transaction
    await WalletTransaction.create({

      user: req.user.id,

      type: "gift",

      title:
        `Sent ${giftType || "gift"} to ${recipientUser.username}`,

      amount: -Number(amount),

      currency: "star",

      status: "completed",

      metadata: {

        recipient,

        postId: postId || null,

        giftType:
          giftType || "standard"

      }

    });

    // Recipient transaction
    await WalletTransaction.create({

      user: recipient,

      type: "gift",

      title:
        `Received ${giftType || "gift"} from ${req.user.username}`,

      amount: nairaValue,

      currency: "money",

      status: "completed",

      metadata: {

        senderId: req.user.id,

        postId: postId || null,

        giftType:
          giftType || "standard"

      }

    });

  
// ═══════════════════════════════
// CREATE GIFT COMMENT
// ═══════════════════════════════

if (postId) {

  const senderUser =
    await User.findById(req.user.id);

  const giftComment =
    await Comment.create({

      post: postId,

      user: req.user.id,

      text:
        `sent a ${giftType} gift 🎁`,

      likes: [],

      mentions: [],

      isGift: true,

      giftType,

      giftStars: Number(amount)

    });

  await giftComment.populate(
    "user",
    "username fullName profilePicture country isVerified"
  );

  // increase comment count
  await Post.findByIdAndUpdate(
    postId,
    {
      $inc: { commentCount: 1 }
    }
  );

}

  
 // ═══════════════════════════════
// GIFT NOTIFICATION
// ═══════════════════════════════

await Notification.create({

  recipient,

  sender: req.user.id,

  type: "gift",

  content:
    `${req.user.username} sent you a ${giftType} gift 🎁`, 

  metadata: {
    giftType,
    stars: Number(amount)
  }

});

// PUSH NOTIFICATION

const payload = {

  title: "New Gift 🎁",

  body:
    `${req.user.username} sent you a ${giftType} gift`,

  icon:  req.user.username.profilePicture,

  click_action: "/notification.html"

};

await sendPushNotification(
  recipient,
  payload
);

    res.json({

      success: true,

      message: "Gift sent successfully"

    });

  } catch (err) {

    console.error(err);

    res.status(500).json({
      message: "Failed to send gift"
    });

  }

};







exports.sendFeedGift = async (req, res) => {

try {

const {
  recipient,
  amount,
  giftType,
  postId
} = req.body;

if (!recipient || !amount || !giftType || !postId) {

  return res.status(400).json({
    message: "Missing required fields"
  });

}

// Prevent self gifting
if (recipient === req.user.id) {

  return res.status(400).json({
    message: "You cannot gift yourself"
  });

}

// Sender wallet
const senderWallet =
  await Wallet.findOne({
    user: req.user.id
  });

if (!senderWallet) {

  return res.status(404).json({
    message: "Wallet not found"
  });

}

// Balance check
if (senderWallet.starBalance < Number(amount)) {

  return res.status(400).json({
    message: "Insufficient stars"
  });

}

// Recipient user
const recipientUser =
  await User.findById(recipient);

if (!recipientUser) {

  return res.status(404).json({
    message: "Recipient not found"
  });

}

// Recipient wallet
let recipientWallet =
  await Wallet.findOne({
    user: recipient
  });

if (!recipientWallet) {

  recipientWallet =
    await Wallet.create({
      user: recipient
    });

}

// Platform fee
const fee =
  Math.floor(Number(amount) * 0.30);

// Creator gets 70%
const creatorStars =
  Number(amount) - fee;

// Convert to naira
const nairaValue =
  creatorStars * 15;

// Deduct sender stars
senderWallet.starBalance -= Number(amount);

// Add creator money
recipientWallet.availableBalance += nairaValue;

await senderWallet.save();
await recipientWallet.save();

// Sender transaction
await WalletTransaction.create({

  user: req.user.id,

  type: "gift",

  title:
    `Sent ${giftType} gift to ${recipientUser.username}`,

  amount: -Number(amount),

  currency: "star",

  status: "completed",

  metadata: {
    recipient,
    postId,
    giftType
  }

});

// Recipient transaction
await WalletTransaction.create({

  user: recipient,

  type: "gift",

  title:
    `Received ${giftType} gift from ${req.user.username}`,

  amount: nairaValue,

  currency: "money",

  status: "completed",

  metadata: {
    senderId: req.user.id,
    postId,
    giftType
  }

});

// CREATE GIFT COMMENT
const giftComment =
  await Comment.create({

    post: postId,

    user: req.user.id,

    text:
      `sent a ${giftType} gift 🎁`,

    likes: [],

    mentions: [],

    isGift: true,

    giftType,

    giftStars: Number(amount)

  });

await giftComment.populate(
  "user",
  "username fullName profilePicture country isVerified"
);

// Increase comment count
await Post.findByIdAndUpdate(
  postId,
  {
    $inc: { commentCount: 1 }
  }
);

// Notification
await Notification.create({

  recipient,

  sender: req.user.id,

  type: "gift",

  content:
    `${req.user.username} sent you a ${giftType} gift 🎁`,

  metadata: {
    giftType,
    stars: Number(amount),
    postId
  }

});

// Push notification
const payload = {

  title: "New Gift 🎁",

  body:
    `${req.user.username} sent you a ${giftType} gift`,

  icon:  req.user.username.profilePicture,

  click_action: "/notification.html"

};

await sendPushNotification(
  recipient,
  payload
);

res.json({

  success: true,

  message: "Gift sent successfully",

  comment: giftComment,

  giftType,
  amount

});

} catch (err) {

console.error(err);

res.status(500).json({
  message: "Failed to send gift"
});

}

};
