const ExploreComment = require("../models/ExploreComment");
const ExplorePost = require("../models/ExplorePost");

exports.createComment = async (req, res) => {
  try {
    const { text, parentComment } = req.body;

    const comment = await ExploreComment.create({
      post: req.params.postId,
      user: req.user.id,
      text,
      parentComment: parentComment || null
    });

    //  increase post count ONLY for root comments
    if (!parentComment) {
      await ExplorePost.findByIdAndUpdate(req.params.postId, {
        $inc: { commentCount: 1 }
      });
    } else {
      // optional: increase reply count
      await ExploreComment.findByIdAndUpdate(parentComment, {
        $inc: { repliesCount: 1 }
      });
    }

    const populated = await comment.populate(
      "user",
      "fullName username profilePicture country isVerified"
    );

    res.status(201).json(populated);

  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to create comment" });
  }
};





exports.getComments = async (req, res) => {
  try {
    const comments = await ExploreComment.find({
      post: req.params.postId,
      parentComment: null
    })
      .populate("user", "fullName username profilePicture country isVerified")
      .sort({ createdAt: 1 });

    res.status(200).json(comments);
  } catch (err) {
    console.error("GET EXPLORE COMMENTS ERROR:", err);
    res.status(500).json({ message: "Failed to load comments" });
  }
};
