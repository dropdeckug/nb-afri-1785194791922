const Poll = require("../models/Poll");
const PollResponse = require("../models/PollResponse");
const { logActivity } = require("./userActivityController");
const Notification = require("../models/Notification");
const User = require("../models/User");
const { sendPushNotification } = require("./notificationController");



// CREATE POLL
exports.createPoll = async (req, res) => {
  try {
    const { question } = req.body;

    let options = [];

    // ===============================
    // HANDLE JSON OPTIONS
    // Supports:
    // options: ["A", "B"]
    // OR
    // options: [{ text: "A" }, { text: "B" }]
    // ===============================
    if (req.body.options) {
      let parsedOptions = req.body.options;

      // If options comes as stringified JSON
      if (typeof parsedOptions === "string") {
        try {
          parsedOptions = JSON.parse(parsedOptions);
        } catch (e) {
          parsedOptions = [];
        }
      }

      if (Array.isArray(parsedOptions)) {
        options = parsedOptions.map(opt => {
          if (typeof opt === "string") {
            return {
              text: opt,
              image: null,
              votes: 0
            };
          }

          return {
            text: opt.text,
            image: opt.image || null,
            votes: 0
          };
        });
      }
    }

    // ===============================
    // HANDLE FORM-DATA TEXT OPTIONS
    // options[0][text], options[1][text]
    // ===============================
    Object.keys(req.body).forEach(key => {
      const match = key.match(/options\[(\d+)\]\[text\]/);

      if (match) {
        const index = parseInt(match[1]);

        options[index] = options[index] || {};
        options[index].text = req.body[key];
        options[index].votes = 0;
      }
    });

    // ===============================
    // HANDLE FORM-DATA IMAGE OPTIONS
    // options[0][image], options[1][image]
    // ===============================
    if (req.files && req.files.length > 0) {
      req.files.forEach(file => {
        const match = file.fieldname.match(/options\[(\d+)\]\[image\]/);

        if (match) {
          const index = parseInt(match[1]);

          options[index] = options[index] || {};
          options[index].image = file.path;
          options[index].votes = 0;
        }
      });
    }

    // ===============================
    // CLEAN OPTIONS
    // ===============================
    options = options
      .filter(opt => opt && opt.text && opt.text.trim() !== "")
      .map(opt => ({
        text: opt.text.trim(),
        image: opt.image || null,
        votes: opt.votes || 0
      }));

    // ===============================
    // VALIDATION
    // ===============================
    if (!question || question.trim() === "") {
      return res.status(400).json({
        message: "Question is required"
      });
    }

    if (options.length < 2) {
      return res.status(400).json({
        message: "Poll must have at least 2 options"
      });
    }

    // ===============================
    // CREATE POLL
    // ===============================
    const poll = await Poll.create({
      user: req.user.id,
      question: question.trim(),
      options
    });

  // ===============================
// NOTIFY FOLLOWERS (BACKGROUND)
// ===============================
const creator =
  await User.findById(req.user.id)
    .populate("followers");

// Run notifications in background
setImmediate(async () => {

  try {

    if (
      creator.followers &&
      creator.followers.length > 0
    ) {

      for (let followerId of creator.followers) {

        // Save notification
        await Notification.create({

          recipient: followerId,

          sender: req.user.id,

          type: "poll",

          poll: poll._id

        });

        // Push notification
        const payload = {

          title: "New Battle Poll 🔥",

          body:
            `${creator.fullName} just created a new battle poll ⚔️`,

          click_action: "/feed.html",

          icon:
            creator.profilePicture ||
            "/uploads/images/africa.png"

        };

        await sendPushNotification(
          followerId,
          payload
        );

      }

    }

  } catch (err) {

    console.error(
      "POLL NOTIFICATION ERROR:",
      err
    );

  }

});
    
    // LOG ACTIVITY
    await logActivity(req.user.id, "poll_create", poll._id);

    res.status(201).json({
      ...poll.toObject(),
      type: "poll"
    });

  } catch (err) {
    console.error("CREATE POLL ERROR:", err);
    res.status(500).json({
      message: "Failed to create poll",
      error: err.message
    });
  }
};





exports.votePoll = async (req, res) => {
  try {
    const { optionId } = req.body;
    const poll = await Poll.findById(req.params.id);

    if (!poll) {
      return res.status(404).json({ message: "Poll not found" });
    }

    // Prevent double voting
    const alreadyVoted = poll.voters.find(
      v => v.user.toString() === req.user.id
    );

    if (alreadyVoted) {
      return res.status(400).json({ message: "Already voted" });
    }

    // Find option
    const option = poll.options.id(optionId);
    if (!option) {
      return res.status(400).json({ message: "Invalid option" });
    }

    option.votes += 1;

    poll.voters.push({
      user: req.user.id,
      optionId
    });

    await poll.save();

    // ===============================
   // NOTIFICATION (VOTE)
  // ===============================
  if (poll.user.toString() !== req.user.id) {

   await Notification.create({
    recipient: poll.user,
    sender: req.user.id,
    type: "poll_vote",
    poll: poll._id
  });

  const sender = await User.findById(req.user.id);

  const payload = {
    title: "New Vote",
    body: `${sender.fullName} voted on your battle poll 🗳️`,
    click_action: "/notification.html",
    icon: sender.profilePicture 
  };

  await sendPushNotification(poll.user, payload);
}

     // LOG ACTIVITY
    await logActivity(req.user.id, "poll_vote", poll._id);

    res.json({ poll });

  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Vote failed" });
  }
};




exports.respondPoll = async (req, res) => {
  try {
    const { text } = req.body;

    const poll = await Poll.findById(req.params.id);

    if (!poll) {
      return res.status(404).json({ message: "Poll not found" });
    }

    if (!text || text.trim() === "") {
      return res.status(400).json({ message: "Response text required" });
    }

    // Handle image (optional)
    let media = null;
    if (req.file) {
      media = req.file.path;
    }

    // Save response
    await PollResponse.create({
      poll: poll._id,
      user: req.user.id,
      text: text.trim(),
      media
    });

    // Increment counter
    poll.respondCount += 1;
    await poll.save();

   // ===============================
  // NOTIFICATION (RESPONSE)
 // ===============================
 if (poll.user.toString() !== req.user.id) {

  await Notification.create({
    recipient: poll.user,
    sender: req.user.id,
    type: "poll_response",
    poll: poll._id
  });

  const sender = await User.findById(req.user.id);

  const payload = {
    title: "New Response",
    body: `${sender.fullName} responded to your battle poll 💬`,
    click_action: "/notification.html",
    icon: sender.profilePicture 
  };

  await sendPushNotification(poll.user, payload);
} 

    // LOG ACTIVITY
    await logActivity(req.user.id, "poll_respond", poll._id);

    res.json({ message: "Response added" });

  } catch (err) {
    console.error("RESPOND ERROR:", err);
    res.status(500).json({ message: "Respond failed" });
  }
};





exports.reactToPoll = async (req, res) => {
  try {
    const { emoji } = req.body;

    if (!emoji) {
      return res.status(400).json({ message: "Emoji is required" });
    }

    const poll = await Poll.findById(req.params.pollId);

    if (!poll) {
      return res.status(404).json({ message: "Poll not found" });
    }

   
    if (!poll.reactions) {
      poll.reactions = [];
    }

    // Check if user already reacted
    const existingReaction = poll.reactions.find(
      r => r.user.toString() === req.user.id
    );

    if (existingReaction) {
      // Same emoji → do nothing
      if (existingReaction.emoji === emoji) {
        return res.json({ message: "Already reacted" });
      }

      // Different emoji → update
      existingReaction.emoji = emoji;
    } else {
      // New reaction
      poll.reactions.push({
        user: req.user.id,
        emoji
      });
    }

    await poll.save();

  // ===============================
 // NOTIFICATION (REACTION)
// ===============================
if (poll.user.toString() !== req.user.id) {

  await Notification.create({
    recipient: poll.user,
    sender: req.user.id,
    type: "poll_react",
    poll: poll._id
  });

  const sender = await User.findById(req.user.id);

  const payload = {
    title: "New Reaction",
    body: `${sender.fullName} reacted ${emoji} to your battle poll`,
    click_action: "/notification.html",
    icon: sender.profilePicture 
  };

  await sendPushNotification(poll.user, payload);
}

    // LOG ACTIVITY
    await logActivity(req.user.id, "poll_react", poll._id);

    res.json({
      message: "Reaction saved",
      reactions: poll.reactions
    });

  } catch (err) {
    console.error("REACT POLL ERROR:", err);
    res.status(500).json({ message: "Failed to react" });
  }
};




exports.getPollVoters = async (req, res) => {
  try {
    const { pollId, optionId } = req.params;

    const poll = await Poll.findById(pollId).populate(
      "voters.user",
      "username fullName profilePicture isVerified"
    );

    if (!poll) {
      return res.status(404).json({ message: "Poll not found" });
    }

    // Filter voters for this specific option
    const voters = poll.voters
      .filter(v => v.optionId === optionId)
      .map(v => v.user);

    res.json({ voters });

  } catch (err) {
    console.error("GET VOTERS ERROR:", err);
    res.status(500).json({ message: "Failed to fetch voters" });
  }
};




exports.getPollResponses = async (req, res) => {
  try {
    const responses = await PollResponse.find({
      poll: req.params.pollId
    })
      .populate("user", "username fullName profilePicture isVerified")
      .sort({ createdAt: -1 });

    res.json({ responses });

  } catch (err) {
    console.error("GET RESPONSES ERROR:", err);
    res.status(500).json({ message: "Failed to fetch responses" });
  }
};





// GET POLLS BY USER
exports.getPollsByUser = async (req, res) => {
  try {
    const userId = req.params.userId;

    if (!userId) {
      return res.status(400).json({ message: "User ID required" });
    }

    const polls = await Poll.find({ user: userId })
      .populate("user", "username fullName profilePicture country isVerified")
      .sort({ createdAt: -1 });

    // Add extra data (like totalVotes, reactions count)
    const pollsWithStats = polls.map(poll => {
      const totalVotes = poll.options?.reduce(
        (sum, opt) => sum + (opt.votes || 0),
        0
      );

      const reactionCount = poll.reactions?.length || 0;

      return {
        ...poll.toObject(),
        totalVotes,
        reactionCount,
        type: "poll"
      };
    });

    res.status(200).json({ polls: pollsWithStats });

  } catch (err) {
    console.error("GET USER POLLS ERROR:", err);
    res.status(500).json({ message: "Failed to fetch user polls" });
  }
};
