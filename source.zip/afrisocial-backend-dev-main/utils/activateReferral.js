const Referral = require("../models/Referral");
const User = require("../models/User");
const Wallet = require("../models/Wallet");
const WalletTransaction = require("../models/WalletTransaction");

module.exports = async function activateReferral(userId) {

try {

const user =
  await User.findById(userId);

if (!user || !user.referredBy) {
  return;
}

// Find referral record
const referral =
  await Referral.findOne({
    referredUser: userId
  });

if (!referral) {
  return;
}

// Already activated
if (referral.isActive) {
  return;
}

// =========================
// CHECK REQUIREMENTS
// =========================

const hasProfilePicture =
  !!user.profilePicture;

const hasPosts =
  (user.totalPosts || 0) >= 1;

const hasEngagement =
  (
    (user.totalLoves || 0) +
    (user.totalComments || 0)
  ) >= 3;

const accountAge =
  Date.now() -
  new Date(user.createdAt).getTime();

const isOldEnough =
  accountAge >= 3 * 24 * 60 * 60 * 1000;

// =========================
// ALL CONDITIONS REQUIRED
// =========================

if (
  !hasProfilePicture ||
  !hasPosts ||
  !hasEngagement ||
  !isOldEnough
) {
  return;
}

// =========================
// GET REFERRER
// =========================

const referrer =
  await User.findById(
    user.referredBy
  );

if (!referrer) {
  return;
}

// =========================
// ACTIVATE REFERRAL
// =========================

referral.isActive = true;

referral.activatedAt =
  new Date();

referral.earnings = 80;

await referral.save();

// =========================
// UPDATE REFERRER
// =========================

referrer.referralEarnings =
  (referrer.referralEarnings || 0)
  + 80;

referrer.activeReferralCount =
  (referrer.activeReferralCount || 0)
  + 1;

await referrer.save();

// =========================
// FIND OR CREATE WALLET
// =========================

let wallet =
  await Wallet.findOne({
    user: referrer._id
  });

if (!wallet) {

  wallet =
    await Wallet.create({
      user: referrer._id
    });

}

// =========================
// CREDIT WALLET
// =========================

wallet.availableBalance += 80;

wallet.totalEarned += 80;

await wallet.save();

// =========================
// CREATE TRANSACTION
// =========================

await WalletTransaction.create({

  user: referrer._id,

  type: "referral",

  title:
    `Referral reward from ${user.username}`,

  amount: 80,

  currency: "NGN",

  status: "completed",

  metadata: {

    referredUser: user._id,

    referralId: referral._id

  }

});

console.log(
  `Referral activated for ${user.username}`
);

} catch (err) {

console.error(
  "ACTIVATE REFERRAL ERROR:",
  err
);

}
};
