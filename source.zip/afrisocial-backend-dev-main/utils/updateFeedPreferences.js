const User = require("../models/User");

module.exports = async function updateFeedPreferences(
  userId,
  hashtags = [],
  weight = 1
) {

  try {

    if (!hashtags.length) return;

    const user =
      await User.findById(userId);

    if (!user) return;

    // Create object if missing
    if (!user.feedPreferences) {
      user.feedPreferences = {};
    }

    hashtags.forEach(tag => {

      const currentScore =
        user.feedPreferences.get(tag) || 0;

      user.feedPreferences.set(
        tag,
        currentScore + weight
      );

    });

    await user.save();

  } catch (err) {

    console.error(
      "FEED PREFERENCE ERROR:",
      err
    );

  }
};
