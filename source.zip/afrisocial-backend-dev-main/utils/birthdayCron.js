const cron = require("node-cron");

const User = require("../models/User");
const Post = require("../models/Post");
const Notification = require("../models/Notification");
const { sendPushNotification } = require("../controllers/notificationController");

cron.schedule("0 0 * * *", async () => {

  console.log("Running birthday check...");

  try {

    const today = new Date();

    const users = await User.find();

    for (const user of users) {

      if (!user.dob) continue;

      const birthDate = new Date(user.dob);

      const isBirthday =
        birthDate.getDate() === today.getDate() &&
        birthDate.getMonth() === today.getMonth();

      if (!isBirthday) continue;

      // Prevent duplicate birthday posts
      const existingPost = await Post.findOne({
        isBirthdayPost: true,
        birthdayFor: user._id,
        createdAt: {
          $gte: new Date(
            new Date().setHours(0, 0, 0, 0)
          )
        }
      });

      if (existingPost) continue;

      // Create birthday post
      const birthdayPost = await Post.create({

        user: user._id,

        birthdayFor: user._id,

        isBirthdayPost: true,

        text:
`🎉 Today is ${user.fullName}'s birthday!
Wish them a happy birthday 🎂❤️`

      });

      console.log(
        `Birthday post created for ${user.fullName}`
      );

      // Notify followers

      const followers = user.followers || [];

      for (const followerId of followers) {

        if (
          followerId.toString() ===
          user._id.toString()
        ) continue;

        await Notification.create({

  recipient: followerId,

  sender: user._id,

  type: "birthday",

  text:
`🎉 Today is ${user.fullName}'s birthday! Wish them a happy birthday 🎂`,

  post: birthdayPost._id

});

// PUSH NOTIFICATION

await sendPushNotification(

  followerId,

  "🎂 Birthday Alert",

  `${user.fullName}'s birthday is today 🎉`,

  {
    postId: birthdayPost._id,
    type: "birthday"
  }

);

      }

      console.log(
        `Birthday notifications sent for ${user.fullName}`
      );

    }

  } catch (err) {

    console.error(
      "Birthday cron error:",
      err
    );

  }

});
