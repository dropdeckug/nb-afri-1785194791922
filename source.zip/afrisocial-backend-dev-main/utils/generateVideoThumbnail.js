const ffmpeg = require("fluent-ffmpeg");

const path = require("path");

const fs = require("fs");

const cloudinary =
require("../config/cloudinary");

const generateVideoThumbnail =
(videoPath) => {

  return new Promise((resolve, reject) => {

    const thumbnailDir =
      path.join(
        __dirname,
        "../uploads/thumbnails"
      );

    // create folder if missing
    if (!fs.existsSync(thumbnailDir)) {

      fs.mkdirSync(thumbnailDir, {
        recursive: true
      });

    }

    const filename =
      `thumb-${Date.now()}.jpg`;

    const outputPath =
      path.join(thumbnailDir, filename);

    ffmpeg(videoPath)

      .screenshots({

        count: 1,

        folder: thumbnailDir,

        filename,

        size: "1280x720"

      })

      .on("end", async () => {

        try {

          // =========================
          // UPLOAD TO CLOUDINARY
          // =========================

          const uploaded =
            await cloudinary.uploader.upload(
              outputPath,
              {
                folder:
                "afrisocial-thumbnails"
              }
            );

          // delete local thumbnail
          fs.unlinkSync(outputPath);

          // return CLOUDINARY URL
          resolve(uploaded.secure_url);

        } catch (err) {

          reject(err);

        }

      })

      .on("error", (err) => {

        console.error(err);

        reject(err);

      });

  });

};

module.exports =
generateVideoThumbnail;
