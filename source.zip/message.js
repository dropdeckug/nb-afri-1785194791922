/* ============================================================
   message.js — X-style inbox with real-time sockets (Phase B done)
   Endpoints used:
     GET    /api/messages/chats
     GET    /api/messages/groups
     GET    /api/messages/:conversationId            (history)
     GET    /api/messages/groups/:groupId/messages
     POST   /api/messages/createConversation         { receiverId }
     POST   /api/messages/send                       { conversationId, text, media, type }
     POST   /api/messages/groups/:groupId            { text, media, type }
     POST   /api/messages/upload-media               (FormData)
     POST   /api/messages/:userId/typing
     POST   /api/messages/:userId/read
     PUT    /api/messages/read/:conversationId
     POST   /api/messages/groups                     { name, members }
     GET    /api/users/search?q=
   Real-time events (via realtime.js socket):
     message:new, message:read, message:deleted, typing:start, typing:stop
   ============================================================ */
(function () {
  "use strict";

  const API   = "https://afrisocial-backend.onrender.com";
  const token = localStorage.getItem("token");
  let meId  = normalizeId(localStorage.getItem("userId"));
  if (!meId && token) {
    meId = readJwtUserId(token);
    if (meId) localStorage.setItem("userId", meId);
  }
  if (!token || !meId) { location.href = "/log-in.html"; return; }

  const PLACEHOLDER = "/uploads/images/africa.png";

  /* ───── tiny helpers ───── */
  const $  = (id) => document.getElementById(id);
  const esc = (s) => { const d = document.createElement("div"); d.textContent = s == null ? "" : String(s); return d.innerHTML; };
  function normalizeId(value) {
    const id = value == null ? "" : String(value).trim();
    return (!id || id === "undefined" || id === "null") ? "" : id;
  }
  function idOf(value) {
    if (!value) return "";
    if (typeof value === "string") return normalizeId(value);
    return normalizeId(value._id || value.id || value.userId);
  }
  function normalizeUser(user) {
    if (!user) return null;
    const id = idOf(user);
    return id ? { ...user, _id: id } : null;
  }
  function readJwtUserId(jwt) {
    try {
      let part = jwt.split(".")[1].replace(/-/g, "+").replace(/_/g, "/");
      part += "=".repeat((4 - part.length % 4) % 4);
      const payload = JSON.parse(atob(part));
      return normalizeId(payload.userId || payload.id || payload._id || payload.sub);
    } catch (_) {
      return "";
    }
  }
  const fmtTime = (d) => new Date(d).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  const fmtRel  = (d) => {
    const s = Math.floor((Date.now() - new Date(d)) / 1000);
    if (s < 60)     return "now";
    if (s < 3600)   return Math.floor(s/60) + "m";
    if (s < 86400)  return Math.floor(s/3600) + "h";
    if (s < 604800) return Math.floor(s/86400) + "d";
    return Math.floor(s/604800) + "w";
  };
  const fmtDay = (d) => {
    const dt = new Date(d), now = new Date();
    if (dt.toDateString() === now.toDateString()) return "Today";
    const yest = new Date(now); yest.setDate(now.getDate() - 1);
    if (dt.toDateString() === yest.toDateString()) return "Yesterday";
    return dt.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
  };
  const toast = (msg) => {
    const t = $("msgToast");
    t.textContent = msg;
    t.classList.add("show");
    const ms = Math.min(7000, Math.max(2600, String(msg || "").length * 55));
    clearTimeout(t._hideTimer);
    t._hideTimer = setTimeout(() => t.classList.remove("show"), ms);
  };

  async function parseResponse(res) {
    const txt = await res.text();
    if (!txt) return {};
    try { return JSON.parse(txt); }
    catch { return { message: txt }; }
  }

  function responseMessage(data, fallback) {
    return (data && (data.message || data.error || data.details)) || fallback;
  }

  async function api(path, opts = {}) {
    const headers = { Authorization: "Bearer " + token };
    if (!(opts.body instanceof FormData)) headers["Content-Type"] = "application/json";
    const res = await fetch(API + path, { ...opts, headers: { ...headers, ...(opts.headers || {}) } });
    const data = await parseResponse(res);
    if (!res.ok) {
      const err = new Error(responseMessage(data, "Request failed") + " (HTTP " + res.status + ")");
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data;
  }

  /* ───── state ───── */
  const state = {
    filter: "all",          // all | chats | groups | archived
    threads: [],            // [{ kind:'dm'|'group', id, name, avatar, lastMessage, updatedAt, unreadCount, otherUserId?, conversationId? }]
    activeKind: null,       // 'dm' | 'group'
    activeKey:  null,       // conversationId or groupId
    activePeer: null,       // for dm: { _id, fullName, profilePicture }
    messages:   [],
    typingTimer: null
  };

  /* ───── load inbox (chats + groups merged) ───── */
  async function loadInbox() {
    try {
      const [chats, groups] = await Promise.all([
        api("/api/messages/chats").catch(() => []),
        api("/api/messages/groups").catch(() => [])
      ]);
      const dmRows = (Array.isArray(chats) ? chats : []).map((c) => ({
        kind: "dm",
        id: c._id,
        conversationId: c._id,
        otherUserId: idOf(c.otherUser),
        name: c.otherUser?.fullName || c.otherUser?.username || "Unknown",
        username: c.otherUser?.username,
        avatar: c.otherUser?.profilePicture || PLACEHOLDER,
        lastMessage: c.lastMessage || "",
        updatedAt: c.updatedAt,
        unreadCount: c.unreadCount || 0,
        peer: normalizeUser(c.otherUser)
      }));
      const grRows = (Array.isArray(groups) ? groups : []).map((g) => ({
        kind: "group",
        id: g._id,
        groupId: g._id,
        name: g.name,
        avatar: g.profilePicture || PLACEHOLDER,
        lastMessage: g.lastMessage || "",
        updatedAt: g.updatedAt,
        unreadCount: g.unreadCount || 0,
        memberCount: g.memberCount
      }));
      state.threads = [...dmRows, ...grRows].sort(
        (a, b) => new Date(b.updatedAt || 0) - new Date(a.updatedAt || 0)
      );
      renderList();
      renderRightRailGroups(grRows);
    } catch (e) {
      console.warn("loadInbox failed:", e.message);
      $("threadList").innerHTML = '<div class="rr-empty" style="padding:16px;">Could not load chats.</div>';
    }
  }

  function renderList(filterText = "") {
    const list = $("threadList");
    const ft = filterText.trim().toLowerCase();
    let rows = state.threads;
    if (state.filter === "chats")    rows = rows.filter(r => r.kind === "dm");
    if (state.filter === "groups")   rows = rows.filter(r => r.kind === "group");
    if (ft) rows = rows.filter(r => (r.name || "").toLowerCase().includes(ft));

    if (!rows.length) {
      list.innerHTML = '<div class="rr-empty" style="padding:16px;">No conversations.</div>';
      return;
    }
    list.innerHTML = rows.map(r => {
      const active = state.activeKey === r.id ? " active" : "";
      const unread = r.unreadCount > 0
        ? '<span class="unread-dot">' + (r.unreadCount > 99 ? "99+" : r.unreadCount) + "</span>"
        : "";
      return (
        '<div class="thread-row' + active + '" data-kind="' + r.kind + '" data-id="' + r.id + '">' +
          '<img class="avatar" src="' + esc(r.avatar) + '" alt="" onerror="this.src=\'' + PLACEHOLDER + '\'">' +
          '<div class="meta">' +
            '<div class="meta-top">' +
              '<strong>' + esc(r.name) + '</strong>' +
              '<span class="time">' + (r.updatedAt ? fmtRel(r.updatedAt) : "") + "</span>" +
            '</div>' +
            '<div class="meta-preview"><span>' + esc(r.lastMessage || (r.kind === "group" ? r.memberCount + " members" : "Tap to chat")) + "</span>" + unread + "</div>" +
          '</div>' +
        '</div>'
      );
    }).join("");

    list.querySelectorAll(".thread-row").forEach(row => {
      row.addEventListener("click", () => {
        const r = state.threads.find(t => t.id === row.dataset.id && t.kind === row.dataset.kind);
        if (r) openThread(r);
      });
    });
  }

  function renderRightRailGroups(groups) {
    const el = $("rrGroups");
    if (!groups.length) {
      el.innerHTML = '<div class="rr-empty">No groups yet. Create one to get started.</div>';
      return;
    }
    el.innerHTML = groups.slice(0, 8).map(g => (
      '<div class="rr-group" data-id="' + esc(g.id || g._id || g.groupId) + '">' +
        '<img src="' + esc(g.avatar) + '" alt="" onerror="this.src=\'' + PLACEHOLDER + '\'">' +
        '<div class="gmeta"><strong>' + esc(g.name) + '</strong><span>' + (g.memberCount || 0) + ' members</span></div>' +
      '</div>'
    )).join("");
    el.querySelectorAll(".rr-group").forEach(n => {
      n.addEventListener("click", () => {
        const row = state.threads.find(t => t.kind === "group" && t.id === n.dataset.id);
        if (row) openThread(row);
      });
    });
  }

  /* ───── open thread ───── */
  async function openThread(row) {
    state.activeKind = row.kind;
    state.activeKey  = row.id;
    state.activePeer = normalizeUser(row.peer) || null;
    state.messages   = [];
    document.body.classList.add("thread-open");
    $("threadEmpty").hidden = true;
    $("thread").hidden = false;

    // ALWAYS reset typing indicator when switching threads.
    $("typingDot").hidden = true;
    if (state.typingHideTimer) { clearTimeout(state.typingHideTimer); state.typingHideTimer = null; }

    $("threadAvatar").src = row.avatar || PLACEHOLDER;
    $("threadAvatar").onerror = () => { $("threadAvatar").src = PLACEHOLDER; };
    $("threadName").textContent = row.name;
    $("threadStatus").textContent = row.kind === "group" ? (row.memberCount || 0) + " members" : "";

    $("msgBody").innerHTML =
      '<div class="skel-row"><div class="skel-avatar"></div><div class="skel-lines"><div class="skel-line short"></div><div class="skel-line medium"></div></div></div>' +
      '<div class="skel-row" style="flex-direction:row-reverse"><div class="skel-avatar"></div><div class="skel-lines" style="align-items:flex-end"><div class="skel-line medium"></div><div class="skel-line short"></div></div></div>' +
      '<div class="skel-row"><div class="skel-avatar"></div><div class="skel-lines"><div class="skel-line long"></div><div class="skel-line medium"></div></div></div>';
    renderList();
    setTimeout(() => { try { $("messageInput").focus(); } catch (_) {} }, 60);

    try {
      let payload;
      if (row.kind === "dm") {
        payload = await api("/api/messages/" + row.conversationId + "?limit=50&page=1");
        if (window.realtime) window.realtime.joinConversation(row.conversationId);
        api("/api/messages/read/" + row.conversationId, { method: "PUT" }).catch(() => {});
        if (row.otherUserId) api("/api/messages/" + row.otherUserId + "/read", { method: "POST" }).catch(() => {});
      } else {
        payload = await api("/api/messages/groups/" + row.groupId + "/messages?limit=50&page=1");
        if (window.realtime) window.realtime.joinGroup(row.groupId);
      }
      state.messages = (payload.messages || []).slice();
      renderMessages();
      const t = state.threads.find(x => x.id === row.id && x.kind === row.kind);
      if (t) { t.unreadCount = 0; renderList(); }
    } catch (e) {
      // empty thread (brand new conversation) is normal — show "say hi" hint
      $("msgBody").innerHTML = '<div class="rr-empty" style="padding:16px;text-align:center;">Say hi 👋 — no messages yet.</div>';
      console.warn("openThread load failed:", e.message);
    }
  }

  function renderMessages() {
    const body = $("msgBody");
    let html = ""; let lastDay = "";
    state.messages.forEach(m => {
      const day = fmtDay(m.createdAt || Date.now());
      if (day !== lastDay) { html += '<div class="day-divider">' + day + '</div>'; lastDay = day; }
      html += bubbleHTML(m);
    });
    body.innerHTML = html;
    body.scrollTop = body.scrollHeight;

    body.querySelectorAll("[data-retry]").forEach(el => {
      el.addEventListener("click", () => retrySend(el.dataset.retry));
    });
    mountVoicePlayers();
    wireBubbleLongPress();
  }

  function bubbleHTML(m) {
    const senderId = (m.sender && (m.sender._id || m.sender)) || m._localSender;
    const out = String(senderId) === String(meId);
    let inner = "";
    // reply quote
    if (m.replyTo && (m.replyTo.text || m.replyTo.media || m.replyTo.type)) {
      const rp = m.replyTo;
      const who = (rp.sender && (rp.sender.fullName || rp.sender.username)) || 'Reply';
      const snip = rp.text || (rp.type === 'image' ? '📷 Photo' : rp.type === 'video' ? '🎬 Video' : rp.type === 'voice' ? '🎙️ Voice message' : '📎 Attachment');
      inner += '<div class="reply-quote"><strong>' + esc(who) + '</strong><span>' + esc(snip) + '</span></div>';
    }
    if (m.media && m.type === "image") {
      inner = '<img class="bubble-media" src="' + esc(m.media) + '" alt="">';
    } else if (m.media && m.type === "video") {
      inner = '<video class="bubble-media" src="' + esc(m.media) + '" controls></video>';
    } else if (m.media && m.type === "voice") {
      const vid = m._id || m._localId || ('v' + Math.random().toString(36).slice(2,8));
      inner += voicePlayerHTML(m.media, vid, m.voiceDuration);
    } else if (m.media) {
      inner += '<a class="bubble-link" href="' + esc(m.media) + '" target="_blank" rel="noopener">📎 attachment</a>';
    }
    if (m.text) inner += '<span>' + esc(m.text) + '</span>';
    const time = m.createdAt ? '<span class="bubble-time">' + fmtTime(m.createdAt) + '</span>' : '';
    let status = "";
    if (out && m._status === "sending") status = '<div class="bubble-status">Sending…</div>';
    if (out && m._status === "failed") {
      const err = m._error ? ': ' + esc(m._error) : '';
      status = '<div class="bubble-status failed" data-retry="' + m._localId + '">Failed' + err + ' — Try Again</div>';
    }
    // group reactions by emoji
    const rxArr = Array.isArray(m.reactions) ? m.reactions : [];
    let rxns = '';
    if (rxArr.length) {
      const counts = {};
      rxArr.forEach(r => { const e = r.emoji || r; counts[e] = (counts[e] || 0) + 1; });
      rxns = '<div class="bubble-reactions">' +
        Object.keys(counts).map(e => '<span class="reaction-chip">' + esc(e) + (counts[e] > 1 ? ' ' + counts[e] : '') + '</span>').join('') +
        '</div>';
    }

    return (
      '<div class="bubble-row ' + (out ? "out" : "in") + '" data-id="' + (m._id || m._localId || "") + '">' +
        '<div class="reply-hint">↩</div>' +
        '<div class="bubble">' + inner + time + '</div>' +
        rxns +
      '</div>' +
      status
    );
  }

  function voicePlayerHTML(media, vid, duration) {
    const dur = duration ? formatDur(Number(duration)) : '0:00';
    return (
      '<div class="voice-player" data-voice="' + esc(media) + '" data-vid="' + esc(vid) + '">' +
        '<button type="button" class="voice-play" aria-label="Play">' +
          '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>' +
        '</button>' +
        '<canvas class="voice-wave" width="200" height="32"></canvas>' +
        '<span class="voice-time">' + dur + '</span>' +
      '</div>'
    );
  }
  function formatDur(s) {
    if (!isFinite(s) || s < 0) s = 0;
    const m = Math.floor(s / 60), ss = Math.floor(s % 60);
    return m + ':' + (ss < 10 ? '0' : '') + ss;
  }

  /* ───── Custom voice player rendering ───── */
  const peakCache = new Map();
  let sharedAudioCtx = null;
  function getAudioCtx() {
    if (!sharedAudioCtx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (AC) sharedAudioCtx = new AC();
    }
    return sharedAudioCtx;
  }
  async function loadPeaks(url, bars) {
    if (peakCache.has(url)) return peakCache.get(url);
    try {
      const res = await fetch(url);
      const buf = await res.arrayBuffer();
      const ctx = getAudioCtx();
      if (!ctx) throw new Error("no AudioContext");
      const audio = await ctx.decodeAudioData(buf.slice(0));
      const data = audio.getChannelData(0);
      const block = Math.floor(data.length / bars);
      const peaks = new Float32Array(bars);
      for (let i = 0; i < bars; i++) {
        let sum = 0;
        for (let j = 0; j < block; j++) sum += Math.abs(data[i * block + j] || 0);
        peaks[i] = sum / block;
      }
      const max = Math.max(...peaks) || 1;
      for (let i = 0; i < bars; i++) peaks[i] = peaks[i] / max;
      const result = { peaks, duration: audio.duration };
      peakCache.set(url, result);
      return result;
    } catch (_) {
      // fallback: random pseudo-peaks
      const peaks = new Float32Array(bars);
      for (let i = 0; i < bars; i++) peaks[i] = 0.3 + Math.random() * 0.7;
      const result = { peaks, duration: 0 };
      peakCache.set(url, result);
      return result;
    }
  }
  function drawWave(canvas, peaks, progress, isOut) {
    const ctx = canvas.getContext("2d");
    const dpr = window.devicePixelRatio || 1;
    const w = canvas.clientWidth || canvas.width;
    const h = canvas.clientHeight || canvas.height;
    if (canvas.width !== w * dpr) { canvas.width = w * dpr; canvas.height = h * dpr; }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    const bars = peaks.length;
    const barW = Math.max(1.5, (w / bars) - 1);
    const gap = (w - barW * bars) / Math.max(1, bars - 1);
    const playedColor = isOut ? 'rgba(255,255,255,1)' : '#f4c542';
    const unplayedColor = isOut ? 'rgba(255,255,255,.45)' : 'rgba(125,133,144,.6)';
    for (let i = 0; i < bars; i++) {
      const bh = Math.max(2, peaks[i] * (h - 4));
      const x = i * (barW + gap);
      const y = (h - bh) / 2;
      ctx.fillStyle = (i / bars) <= progress ? playedColor : unplayedColor;
      ctx.beginPath();
      const r = barW / 2;
      ctx.roundRect ? ctx.roundRect(x, y, barW, bh, r) : ctx.rect(x, y, barW, bh);
      ctx.fill();
    }
  }
  function mountVoicePlayers() {
    document.querySelectorAll('.voice-player:not([data-mounted])').forEach(el => {
      el.setAttribute('data-mounted', '1');
      const url = el.getAttribute('data-voice');
      const canvas = el.querySelector('.voice-wave');
      const playBtn = el.querySelector('.voice-play');
      const timeEl = el.querySelector('.voice-time');
      const isOut = !!el.closest('.bubble-row.out');
      const BARS = 40;
      let audio = null, peaks = null, duration = 0, playing = false, raf = 0;

      const render = (progress) => { if (peaks) drawWave(canvas, peaks, progress, isOut); };
      render(0);

      loadPeaks(url, BARS).then(r => {
        peaks = r.peaks; duration = r.duration || duration;
        if (duration && timeEl.textContent === '0:00') timeEl.textContent = formatDur(duration);
        render(0);
      });

      const setIcon = (p) => {
        playBtn.innerHTML = p
          ? '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M6 5h4v14H6zM14 5h4v14h-4z"/></svg>'
          : '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>';
      };

      const ensureAudio = () => {
        if (audio) return audio;
        audio = new Audio(url);
        audio.preload = 'metadata';
        audio.addEventListener('loadedmetadata', () => {
          if (audio.duration && isFinite(audio.duration)) {
            duration = audio.duration;
            timeEl.textContent = formatDur(duration);
          }
        });
        audio.addEventListener('ended', () => { playing = false; setIcon(false); render(0); cancelAnimationFrame(raf); });
        audio.addEventListener('pause', () => { playing = false; setIcon(false); cancelAnimationFrame(raf); });
        return audio;
      };

      const tick = () => {
        if (!playing || !audio) return;
        const p = duration ? (audio.currentTime / duration) : 0;
        render(p);
        timeEl.textContent = formatDur(duration - audio.currentTime);
        raf = requestAnimationFrame(tick);
      };

      playBtn.addEventListener('click', () => {
        const a = ensureAudio();
        if (playing) { a.pause(); return; }
        // pause other players
        document.querySelectorAll('.voice-player audio').forEach(x => x.pause());
        a.play().then(() => { playing = true; setIcon(true); tick(); }).catch(() => {});
      });
      canvas.addEventListener('click', (e) => {
        const a = ensureAudio();
        const rect = canvas.getBoundingClientRect();
        const p = (e.clientX - rect.left) / rect.width;
        if (duration) a.currentTime = Math.max(0, Math.min(duration, duration * p));
        render(p);
      });
    });
  }

  /* ───── Long-press reactions ───── */
  const REACTIONS = ['❤️','😂','😮','😢','🙏','👍','👎','🔥','🎉','💯'];

  function closeMenus() {
    document.querySelectorAll('.reaction-picker, .msg-action-sheet, .msg-action-sheet-backdrop').forEach(n => n.remove());
  }

  async function sendReaction(msgId, emoji) {
    if (!msgId || String(msgId).startsWith('lcl_')) return;
    try {
      const res = await api('/api/messages/message/' + msgId + '/react', {
        method: 'POST', body: JSON.stringify({ emoji })
      });
      const m = state.messages.find(x => String(x._id) === String(msgId));
      if (m && res && res.reactions) { m.reactions = res.reactions; renderMessages(); }
    } catch (e) { toast(e.message || 'Reaction failed'); }
  }

  function openReactionPicker(bubbleRow) {
    closeMenus();
    const picker = document.createElement('div');
    picker.className = 'reaction-picker';
    picker.innerHTML = REACTIONS.map(r => '<button type="button" data-emoji="' + r + '">' + r + '</button>').join('');
    document.body.appendChild(picker);
    const rect = bubbleRow.getBoundingClientRect();
    const pr = picker.getBoundingClientRect();
    let top = rect.top - pr.height - 8 + window.scrollY;
    if (top < 8) top = rect.bottom + 8 + window.scrollY;
    let left = rect.left + (rect.width - pr.width) / 2;
    left = Math.max(8, Math.min(window.innerWidth - pr.width - 8, left));
    picker.style.top = top + 'px';
    picker.style.left = left + 'px';
    picker.querySelectorAll('button').forEach(b => {
      b.addEventListener('click', () => {
        const id = bubbleRow.dataset.id;
        sendReaction(id, b.dataset.emoji);
        closeMenus();
      });
    });
  }

  function openActionSheet(bubbleRow) {
    closeMenus();
    const id = bubbleRow.dataset.id;
    const m = state.messages.find(x => String(x._id || x._localId) === String(id));
    if (!m) return;
    const isMine = String((m.sender && (m.sender._id || m.sender)) || m._localSender) === String(meId);
    const isSaved = !!m._id && !String(m._id).startsWith('lcl_');
    const ageOk = m.createdAt ? (Date.now() - new Date(m.createdAt).getTime() < 60 * 60 * 1000) : true;

    const backdrop = document.createElement('div');
    backdrop.className = 'msg-action-sheet-backdrop';
    const sheet = document.createElement('div');
    sheet.className = 'msg-action-sheet';
    sheet.innerHTML =
      '<div class="asheet-reactions">' +
        REACTIONS.map(r => '<button type="button" data-emoji="' + r + '">' + r + '</button>').join('') +
      '</div>' +
      '<button type="button" class="asheet-item" data-act="reply">↩️ Reply</button>' +
      (m.text ? '<button type="button" class="asheet-item" data-act="copy">📋 Copy</button>' : '') +
      (isSaved ? '<button type="button" class="asheet-item danger" data-act="delme">🗑️ Delete for me</button>' : '') +
      (isSaved && isMine && ageOk ? '<button type="button" class="asheet-item danger" data-act="delall">🗑️ Delete for everyone</button>' : '');
    document.body.appendChild(backdrop);
    document.body.appendChild(sheet);

    backdrop.addEventListener('click', closeMenus);

    sheet.querySelectorAll('.asheet-reactions button').forEach(b => {
      b.addEventListener('click', () => { sendReaction(id, b.dataset.emoji); closeMenus(); });
    });

    sheet.querySelectorAll('.asheet-item').forEach(b => {
      b.addEventListener('click', async () => {
        const act = b.dataset.act;
        closeMenus();
        if (act === 'reply') {
          setReplyTo(m);
        } else if (act === 'copy') {
          try { await navigator.clipboard.writeText(m.text || ''); toast('Copied'); }
          catch (_) { toast('Copy failed'); }
        } else if (act === 'delme' || act === 'delall') {
          const forEveryone = act === 'delall';
          try {
            await api('/api/messages/message/' + m._id, {
              method: 'DELETE', body: JSON.stringify({ forEveryone })
            });
            const i = state.messages.findIndex(x => String(x._id) === String(m._id));
            if (i >= 0) {
              if (forEveryone) state.messages.splice(i, 1);
              else { state.messages[i].text = ''; state.messages[i].media = ''; state.messages[i].type = 'text'; state.messages[i]._deletedForMe = true; }
              renderMessages();
            }
          } catch (e) { toast(e.message || 'Delete failed'); }
        }
      });
    });
  }

  /* Long-press + swipe-to-reply on bubbles */
  function wireBubbleLongPress() {
    const body = $("msgBody");
    if (!body || body._lpWired) return;
    body._lpWired = true;

    let lpTimer = null, row = null;
    let startX = 0, startY = 0, dragging = false, moved = false;

    const start = (e) => {
      row = e.target.closest('.bubble-row');
      if (!row) return;
      const pt = e.touches ? e.touches[0] : e;
      startX = pt.clientX; startY = pt.clientY;
      dragging = true; moved = false;
      lpTimer = setTimeout(() => { if (row && !moved) openActionSheet(row); lpTimer = null; }, 450);
    };
    const move = (e) => {
      if (!dragging || !row) return;
      const pt = e.touches ? e.touches[0] : e;
      const dx = pt.clientX - startX, dy = pt.clientY - startY;
      if (Math.abs(dx) > 6 || Math.abs(dy) > 6) moved = true;
      if (moved && lpTimer) { clearTimeout(lpTimer); lpTimer = null; }
      // Horizontal reply swipe: outgoing swipe left, incoming swipe right
      const isOut = row.classList.contains('out');
      const dir = isOut ? Math.min(0, dx) : Math.max(0, dx);
      if (Math.abs(dy) < 30 && Math.abs(dir) > 6) {
        const clamped = Math.max(-80, Math.min(80, dir));
        row.style.transform = 'translateX(' + clamped + 'px)';
        row.classList.toggle('reply-armed', Math.abs(clamped) > 45);
      }
    };
    const end = () => {
      if (lpTimer) { clearTimeout(lpTimer); lpTimer = null; }
      if (row) {
        const armed = row.classList.contains('reply-armed');
        row.style.transform = '';
        row.classList.remove('reply-armed');
        if (armed) {
          const id = row.dataset.id;
          const m = state.messages.find(x => String(x._id || x._localId) === String(id));
          if (m) setReplyTo(m);
        }
      }
      row = null; dragging = false; moved = false;
    };

    body.addEventListener('mousedown', start);
    body.addEventListener('touchstart', start, { passive: true });
    body.addEventListener('mousemove', move);
    body.addEventListener('touchmove', move, { passive: true });
    ['mouseup','mouseleave','touchend','touchcancel'].forEach(ev => body.addEventListener(ev, end));
    body.addEventListener('scroll', () => { if (lpTimer) { clearTimeout(lpTimer); lpTimer = null; } }, true);
    document.addEventListener('click', (e) => {
      if (!e.target.closest('.reaction-picker') && !e.target.closest('.msg-action-sheet') && !e.target.closest('.bubble-row')) closeMenus();
    });
  }

  /* ───── Reply preview in composer ───── */
  function setReplyTo(m) {
    state.replyTo = {
      _id: m._id || null,
      text: m.text || '',
      type: m.type || 'text',
      media: m.media || '',
      senderName: (m.sender && (m.sender.fullName || m.sender.username)) || (String((m.sender && (m.sender._id || m.sender)) || m._localSender) === String(meId) ? 'You' : '')
    };
    renderReplyPreview();
    try { $("messageInput").focus(); } catch (_) {}
  }
  function clearReplyTo() { state.replyTo = null; renderReplyPreview(); }
  function renderReplyPreview() {
    let el = document.getElementById('replyPreview');
    if (!state.replyTo) { if (el) el.remove(); return; }
    if (!el) {
      el = document.createElement('div');
      el.id = 'replyPreview';
      el.className = 'reply-preview';
      const composer = $("composer");
      composer.parentNode.insertBefore(el, composer);
    }
    const r = state.replyTo;
    const snippet = r.text || (r.type === 'image' ? '📷 Photo' : r.type === 'video' ? '🎬 Video' : r.type === 'voice' ? '🎙️ Voice message' : '📎 Attachment');
    el.innerHTML =
      '<div class="rp-bar"></div>' +
      '<div class="rp-meta"><strong>' + esc(r.senderName || 'Reply') + '</strong><span>' + esc(snippet) + '</span></div>' +
      '<button type="button" class="rp-close" aria-label="Cancel reply">✕</button>';
    el.querySelector('.rp-close').addEventListener('click', clearReplyTo);
  }

  /* ───── send ───── */
  function localId() { return "lcl_" + Math.random().toString(36).slice(2, 10); }

  async function ensureConversationReady() {
    if (state.activeKey) return state.activeKey;
    // Lazy-create DM conversation if we only have the peer (creation earlier failed/skipped).
    if (state.activeKind === "dm" && state.activePeer && state.activePeer._id) {
      const rid = idOf(state.activePeer);
      if (!rid) throw new Error("Missing recipient");
      const conv = await api("/api/messages/createConversation", {
        method: "POST", body: JSON.stringify({ receiverId: rid })
      });
      if (!conv || !conv._id) throw new Error("Could not start chat");
      state.activeKey = conv._id;
      if (window.realtime) window.realtime.joinConversation(conv._id);
      // upsert inbox row
      let row = state.threads.find(t => t.kind === "dm" && t.id === conv._id);
      if (!row) {
        state.threads.unshift({
          kind: "dm", id: conv._id, conversationId: conv._id, otherUserId: rid,
          name: state.activePeer.fullName || state.activePeer.username || "User",
          username: state.activePeer.username,
          avatar: state.activePeer.profilePicture || PLACEHOLDER,
          lastMessage: "", updatedAt: new Date().toISOString(),
          unreadCount: 0, peer: state.activePeer
        });
        renderList();
      }
      return state.activeKey;
    }
    throw new Error("No active chat");
  }

  async function sendText(text, media, type, options = {}) {
    const lid = localId();
    const replyTo = state.replyTo ? state.replyTo._id : null;
    const replyToPreview = state.replyTo ? {
      _id: state.replyTo._id,
      text: state.replyTo.text,
      type: state.replyTo.type,
      media: state.replyTo.media,
      sender: { fullName: state.replyTo.senderName }
    } : null;
    const optimistic = {
      _localId: lid, _localSender: meId, _status: "sending",
      text: text || "", media: media || "", type: type || "text", voiceDuration: options.voiceDuration || "",
      createdAt: new Date().toISOString(),
      sender: { _id: meId },
      replyTo: replyToPreview
    };
    state.messages.push(optimistic);
    clearReplyTo();
    renderMessages();

    try {
      const convId = await ensureConversationReady();
      let res;
      if (state.activeKind === "dm") {
        res = await api("/api/messages/send", {
          method: "POST",
          body: JSON.stringify({ conversationId: convId, text, media, type, voiceDuration: options.voiceDuration || "", replyTo: replyTo || undefined })
        });
        const saved = res.data || res.message || res;
        if (!saved || typeof saved !== "object") throw new Error("Server returned an invalid message payload");
        replaceOptimistic(lid, saved);
      } else {
        res = await api("/api/messages/groups/" + state.activeKey, {
          method: "POST",
          body: JSON.stringify({ text, media, type, voiceDuration: options.voiceDuration || "", replyTo: replyTo || undefined })
        });
        if (!res || typeof res !== "object") throw new Error("Server returned an invalid message payload");
        replaceOptimistic(lid, res);
      }
      // bump inbox row
      const t = state.threads.find(x => x.id === state.activeKey && x.kind === state.activeKind);
      if (t) { t.lastMessage = text || (type === "image" ? "📷 Photo" : type === "video" ? "🎬 Video" : "Message"); t.updatedAt = new Date().toISOString(); renderList(); }
    } catch (e) {
      const m = state.messages.find(x => x._localId === lid);
      if (m) { m._status = "failed"; m._error = e && e.message ? e.message : "Send failed"; renderMessages(); }
      toast(e && e.message ? ("Send failed: " + e.message) : "Send failed");
    }
  }

  function replaceOptimistic(lid, saved) {
    const i = state.messages.findIndex(x => x._localId === lid);
    if (i >= 0) state.messages[i] = saved;
    else state.messages.push(saved);
    renderMessages();
  }

  function retrySend(lid) {
    const i = state.messages.findIndex(x => x._localId === lid);
    if (i < 0) return;
    const m = state.messages[i];
    state.messages.splice(i, 1);
    renderMessages();
    sendText(m.text, m.media, m.type);
  }

  /* ───── DM creation (from user picker) ─────
     Flow: close picker → flip UI → CREATE conversation (await) → load history.
     activeKey is ALWAYS a real conversation id before send is possible. */
  async function startDMWith(user) {
    user = normalizeUser(user);
    if (!user || !user._id) { toast("Pick a user first"); return; }

    // Close picker immediately
    $("newChatModal").hidden = true;
    $("userResults").innerHTML = "";
    $("userSearch").value = "";

    // Flip UI to the thread pane immediately with a loading state
    state.activeKind = "dm";
    state.activeKey  = null;
    state.activePeer = user;
    state.messages   = [];
    document.body.classList.add("thread-open");
    $("threadEmpty").hidden = true;
    $("thread").hidden = false;
    $("typingDot").hidden = true;
    $("threadAvatar").src = user.profilePicture || PLACEHOLDER;
    $("threadAvatar").onerror = () => { $("threadAvatar").src = PLACEHOLDER; };
    $("threadName").textContent = user.fullName || user.username || "User";
    $("threadStatus").textContent = "";
    $("msgBody").innerHTML = '<div class="rr-empty" style="padding:16px;text-align:center;">Opening chat…</div>';


    // Background: create/find the conversation. NEVER block the composer if it fails —
    // ensureConversationReady() will retry lazily when the user actually sends.
    try {
      const conv = await api("/api/messages/createConversation", {
        method: "POST", body: JSON.stringify({ receiverId: user._id })
      });
      if (conv && conv._id) {
        let row = state.threads.find(t => t.kind === "dm" && t.id === conv._id);
        if (!row) {
          row = {
            kind: "dm", id: conv._id, conversationId: conv._id, otherUserId: idOf(user),
            name: user.fullName || user.username || "User",
            username: user.username,
            avatar: user.profilePicture || PLACEHOLDER,
            lastMessage: "", updatedAt: new Date().toISOString(),
            unreadCount: 0, peer: user
          };
          state.threads.unshift(row);
          renderList();
        }
        state.activeKey = conv._id;
        if (window.realtime) window.realtime.joinConversation(conv._id);

        try {
          const payload = await api("/api/messages/" + conv._id + "?limit=50&page=1");
          state.messages = (payload.messages || []).slice();
          if (state.messages.length) renderMessages();
          else $("msgBody").innerHTML = '<div class="rr-empty" style="padding:16px;text-align:center;">Say hi 👋 — no messages yet.</div>';
          api("/api/messages/read/" + conv._id, { method: "PUT" }).catch(() => {});
        } catch (_) {
          $("msgBody").innerHTML = '<div class="rr-empty" style="padding:16px;text-align:center;">Say hi 👋 — no messages yet.</div>';
        }
      } else {
        $("msgBody").innerHTML = '<div class="rr-empty" style="padding:16px;text-align:center;">Say hi 👋 — type a message to begin.</div>';
      }
    } catch (e) {
      // Keep composer enabled; we'll retry on first send.
      console.warn("startDMWith create deferred:", e.message);
      $("msgBody").innerHTML = '<div class="rr-empty" style="padding:16px;text-align:center;">Say hi 👋 — type a message to begin.</div>';
    } finally {
      setTimeout(() => { try { $("messageInput").focus(); } catch (_) {} }, 60);
    }
  }


  /* ───── socket wiring ───── */
  function wireSockets() {
    if (!window.realtime) return;
    window.realtime.connect();

    window.realtime.on("message:new", (msg) => {
      const convId  = msg.conversation && (msg.conversation._id || msg.conversation);
      const groupId = msg.group && (msg.group._id || msg.group);
      const key = convId || groupId; if (!key) return;

      // active thread?
      if (String(state.activeKey) === String(key)) {
        // skip if it's our own echo we already inserted (same _id) or matches optimistic
        if (msg._id && state.messages.some(m => String(m._id) === String(msg._id))) return;
        state.messages.push(msg);
        renderMessages();
        // mark read
        if (convId) api("/api/messages/read/" + convId, { method: "PUT" }).catch(() => {});
      }
      // update inbox row (or create if missing)
      let row = state.threads.find(t => t.id === String(key));
      if (row) {
        row.lastMessage = msg.text || (msg.type === "image" ? "📷 Photo" : msg.type === "video" ? "🎬 Video" : "Message");
        row.updatedAt = msg.createdAt || new Date().toISOString();
        const senderId = msg.sender && (msg.sender._id || msg.sender);
        if (String(senderId) !== String(meId) && String(state.activeKey) !== String(key)) {
          row.unreadCount = (row.unreadCount || 0) + 1;
        }
        state.threads.sort((a, b) => new Date(b.updatedAt || 0) - new Date(a.updatedAt || 0));
        renderList();
      } else {
        // refresh inbox to pull the new thread metadata
        loadInbox();
      }
    });

    window.realtime.on("message:deleted", ({ _id }) => {
      const i = state.messages.findIndex(m => String(m._id) === String(_id));
      if (i >= 0) { state.messages.splice(i, 1); renderMessages(); }
    });

    window.realtime.on("message:reaction", ({ _id, reactions }) => {
      const m = state.messages.find(x => String(x._id) === String(_id));
      if (m) { m.reactions = reactions || []; renderMessages(); }
    });

    window.realtime.on("typing:start", ({ conversationId, from }) => {
      // never show typing dot for our own echo
      if (String(from) === String(meId)) return;
      if (String(state.activeKey) !== String(conversationId)) return;
      $("typingDot").hidden = false;
      // safety auto-hide if peer never sends typing:stop
      if (state.typingHideTimer) clearTimeout(state.typingHideTimer);
      state.typingHideTimer = setTimeout(() => { $("typingDot").hidden = true; }, 4000);
    });
    window.realtime.on("typing:stop", ({ conversationId }) => {
      if (String(state.activeKey) === String(conversationId)) {
        $("typingDot").hidden = true;
        if (state.typingHideTimer) { clearTimeout(state.typingHideTimer); state.typingHideTimer = null; }
      }
    });
  }

  /* ───── user search (new DM) ───── */
  async function searchUsers(q) {
    const r = $("userResults");
    if (!q.trim()) { r.innerHTML = ""; return; }
    try {
      const data = await api("/api/users/search?q=" + encodeURIComponent(q));
      const users = Array.isArray(data) ? data : (data.users || []);
      r.innerHTML = users.slice(0, 20).map(u => (
        '<div class="msg-user-row" data-id="' + esc(idOf(u)) + '">' +
          '<img src="' + esc(u.profilePicture || PLACEHOLDER) + '" alt="" onerror="this.src=\'' + PLACEHOLDER + '\'">' +
          '<div class="u-meta"><strong>' + esc(u.fullName || u.username) + '</strong><span>@' + esc(u.username || "") + '</span></div>' +
        '</div>'
      )).join("");
      r.querySelectorAll(".msg-user-row").forEach(el => {
        el.addEventListener("click", () => {
          const u = normalizeUser(users.find(x => idOf(x) === el.dataset.id));
          $("newChatModal").hidden = true;
          if (u) startDMWith(u);
        });
      });
    } catch (e) {
      r.innerHTML = '<div class="rr-empty">' + esc(e.message) + '</div>';
    }
  }

  /* ───── group creation ───── */
  const groupSel = new Map(); // id -> user

  function updateCreateBtn() {
    const btn = $("createGroupBtn");
    const n = groupSel.size;
    btn.textContent = n ? ("Create group (" + n + ")") : "Create group";
    btn.disabled = !$("groupName").value.trim();
    btn.style.opacity = btn.disabled ? ".5" : "1";
  }

  async function searchGroupCandidates(q) {
    const r = $("groupCandidates");
    if (!q.trim()) { r.innerHTML = ""; return; }
    try {
      const data = await api("/api/users/search?q=" + encodeURIComponent(q));
      const users = Array.isArray(data) ? data : (data.users || []);
      r.innerHTML = users.slice(0, 20).map(u => {
        const uid = idOf(u);
        const picked = groupSel.has(uid) ? " picked" : "";
        return (
          '<div class="msg-user-row' + picked + '" data-id="' + esc(uid) + '">' +
            '<img src="' + esc(u.profilePicture || PLACEHOLDER) + '" alt="" onerror="this.src=\'' + PLACEHOLDER + '\'">' +
            '<div class="u-meta"><strong>' + esc(u.fullName || u.username) + '</strong><span>@' + esc(u.username || "") + '</span></div>' +
            '<span class="pick-mark">' + (picked ? "✓" : "+") + '</span>' +
          '</div>'
        );
      }).join("");
      r.querySelectorAll(".msg-user-row").forEach(el => {
        el.addEventListener("click", () => {
          const id = el.dataset.id;
          const u = normalizeUser(users.find(x => idOf(x) === id));
          if (!u) return;
          if (groupSel.has(id)) {
            groupSel.delete(id);
            el.classList.remove("picked");
            el.querySelector(".pick-mark").textContent = "+";
          } else {
            groupSel.set(id, u);
            el.classList.add("picked");
            el.querySelector(".pick-mark").textContent = "✓";
          }
          renderChips();
          updateCreateBtn();
        });
      });
    } catch (e) {
      r.innerHTML = '<div class="rr-empty">' + esc(e.message) + '</div>';
    }
  }
  function renderChips() {
    const el = $("groupChosen");
    if (!groupSel.size) { el.innerHTML = '<span class="rr-empty" style="padding:0;">No members yet — search and tap to add.</span>'; return; }
    el.innerHTML = [...groupSel.values()].map(u =>
      '<span class="msg-chip" data-id="' + u._id + '">' + esc(u.fullName || u.username) + ' <span class="x">✕</span></span>'
    ).join("");
    el.querySelectorAll(".msg-chip .x").forEach(x => x.addEventListener("click", (e) => {
      const id = e.target.parentElement.dataset.id;
      groupSel.delete(id); renderChips(); updateCreateBtn();
      // also un-mark the row if visible
      const row = document.querySelector('#groupCandidates .msg-user-row[data-id="' + id + '"]');
      if (row) { row.classList.remove("picked"); const m = row.querySelector(".pick-mark"); if (m) m.textContent = "+"; }
    }));
  }
  async function createGroup() {
    const name = $("groupName").value.trim();
    if (!name) return toast("Group name required");
    if (!groupSel.size) return toast("Add at least one member");
    const btn = $("createGroupBtn");
    btn.disabled = true; btn.textContent = "Creating…";
    try {
      const group = await api("/api/messages/groups", {
        method: "POST", body: JSON.stringify({ name, members: [...groupSel.keys()] })
      });
      $("groupModal").hidden = true;
      groupSel.clear(); $("groupName").value = ""; $("groupMemberSearch").value = "";
      $("groupCandidates").innerHTML = ""; renderChips(); updateCreateBtn();
      await loadInbox();
      let row = state.threads.find(t => t.kind === "group" && t.id === group._id);
      if (!row) {
        // synthesize a row so we can open immediately even before inbox refresh sees it
        row = {
          kind: "group", id: group._id, groupId: group._id,
          name: group.name, avatar: group.profilePicture || PLACEHOLDER,
          lastMessage: "", updatedAt: new Date().toISOString(),
          unreadCount: 0, memberCount: (group.members || []).length
        };
        state.threads.unshift(row); renderList();
      }
      openThread(row);
      toast("Group created");
    } catch (e) {
      toast(e.message || "Failed to create group");
    } finally {
      btn.disabled = false; updateCreateBtn();
    }
  }

  /* ───── file upload ───── */
  async function uploadFile(file) {
    const fd = new FormData(); fd.append("file", file);
    const res = await fetch(API + "/api/messages/upload-media", {
      method: "POST", headers: { Authorization: "Bearer " + token }, body: fd
    });
    const data = await parseResponse(res);
    if (!res.ok) throw new Error(responseMessage(data, "Upload failed") + " (HTTP " + res.status + ")");
    if (!data.url) throw new Error("Upload completed but no media URL was returned");
    return data; // { url, type }
  }

  /* ───── wire UI ───── */
  function wire() {

  function wireMic() {
    const micBtn = $("micBtn");
    if (!micBtn) return;
    let mediaRec = null, chunks = [], stream = null, startedAt = 0;
    let recording = false, locked = false, cancelled = false;
    let startX = 0, startY = 0, overlay = null, lockInd = null, timerId = 0;

    const canSend = () => !!state.activeKey || (state.activeKind === "dm" && state.activePeer);
    const stopStream = () => { try { stream && stream.getTracks().forEach(t => t.stop()); } catch (_) {} stream = null; };

    function showLockIndicator() {
      lockInd = document.createElement('div');
      lockInd.className = 'mic-lock-indicator';
      lockInd.innerHTML = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg><span>Slide up to lock</span>';
      document.body.appendChild(lockInd);
    }
    function showOverlay() {
      overlay = document.createElement('div');
      overlay.className = 'mic-overlay';
      overlay.innerHTML =
        '<span class="mic-dot"></span>' +
        '<span class="mic-timer">0:00</span>' +
        '<span class="mic-hint">' + (locked ? 'Recording…' : '← Slide to cancel') + '</span>' +
        '<button type="button" class="mic-cancel">Cancel</button>' +
        (locked ? '<button type="button" class="mic-send">Send</button>' : '');
      document.body.appendChild(overlay);
      overlay.querySelector('.mic-cancel').addEventListener('click', () => { cancelled = true; stop(); });
      const sb = overlay.querySelector('.mic-send'); if (sb) sb.addEventListener('click', stop);
      timerId = setInterval(() => {
        const s = Math.floor((Date.now() - startedAt) / 1000);
        const t = overlay && overlay.querySelector('.mic-timer'); if (t) t.textContent = formatDur(s);
      }, 250);
    }
    function teardownUI() {
      if (timerId) { clearInterval(timerId); timerId = 0; }
      if (overlay) { overlay.remove(); overlay = null; }
      if (lockInd) { lockInd.remove(); lockInd = null; }
      micBtn.classList.remove('recording');
    }

    const start = async (e) => {
      if (!canSend() || recording) return;
      if (!navigator.mediaDevices || !window.MediaRecorder) { toast("Voice not supported"); return; }
      const pt = e.touches ? e.touches[0] : e;
      startX = pt.clientX; startY = pt.clientY;
      try { stream = await navigator.mediaDevices.getUserMedia({ audio: true }); }
      catch (_) { toast("Microphone permission denied"); return; }
      chunks = []; startedAt = Date.now();
      recording = true; locked = false; cancelled = false;
      micBtn.classList.add('recording');
      try { mediaRec = new MediaRecorder(stream, { mimeType: "audio/webm" }); }
      catch (_) { mediaRec = new MediaRecorder(stream); }
      mediaRec.ondataavailable = (ev) => { if (ev.data && ev.data.size) chunks.push(ev.data); };
      mediaRec.onstop = async () => {
        teardownUI(); stopStream();
        const wasCancelled = cancelled;
        recording = false; locked = false;
        if (wasCancelled || !chunks.length) { chunks = []; return; }
        const blob = new Blob(chunks, { type: chunks[0].type || "audio/webm" });
        const dur = Math.max(1, Math.round((Date.now() - startedAt) / 1000));
        chunks = [];
        if (blob.size < 800) { toast("Too short"); return; }
        try {
          toast("Sending voice…");
          const file = new File([blob], "voice-" + Date.now() + ".webm", { type: blob.type || "audio/webm" });
          const up = await uploadFile(file);
          await sendText("", up.url, "voice", { voiceDuration: String(dur) });
        } catch (err) { toast(err.message || "Voice send failed"); }
      };
      mediaRec.start();
      showLockIndicator();
      showOverlay();
    };
    const move = (e) => {
      if (!recording || locked) return;
      const pt = e.touches ? e.touches[0] : e;
      const dx = pt.clientX - startX, dy = pt.clientY - startY;
      if (lockInd) {
        lockInd.classList.toggle('armed', dy < -40);
      }
      if (dy < -60) {
        locked = true;
        if (lockInd) { lockInd.remove(); lockInd = null; }
        // upgrade overlay with Send button
        if (overlay) {
          const hint = overlay.querySelector('.mic-hint'); if (hint) hint.textContent = 'Recording… (locked)';
          if (!overlay.querySelector('.mic-send')) {
            const sb = document.createElement('button');
            sb.type = 'button'; sb.className = 'mic-send'; sb.textContent = 'Send';
            sb.addEventListener('click', stop);
            overlay.appendChild(sb);
          }
        }
      } else if (dx < -80) {
        cancelled = true; stop();
      }
    };
    const stop = () => { try { mediaRec && mediaRec.state !== "inactive" && mediaRec.stop(); } catch (_) {} };
    const release = () => { if (recording && !locked) stop(); };

    micBtn.addEventListener("mousedown", start);
    micBtn.addEventListener("touchstart", (e) => { e.preventDefault(); start(e); }, { passive: false });
    document.addEventListener("mousemove", move);
    document.addEventListener("touchmove", move, { passive: true });
    ["mouseup","touchend","touchcancel"].forEach(ev => document.addEventListener(ev, release));
  }

    // chat list
    $("searchInput").addEventListener("input", (e) => renderList(e.target.value));

    // filter pill cycles: All → Chats → Groups → All
    $("filterBtn").addEventListener("click", () => {
      const order = ["all", "chats", "groups"];
      const i = order.indexOf(state.filter);
      state.filter = order[(i + 1) % order.length];
      $("filterLabel").textContent = state.filter[0].toUpperCase() + state.filter.slice(1);
      renderList($("searchInput").value);
    });

    // new chat
    $("newChatFab").addEventListener("click", () => { $("newChatModal").hidden = false; setTimeout(() => $("userSearch").focus(), 50); });
    $("emptyNewChat").addEventListener("click", () => $("newChatFab").click());
    $("closeNewChat").addEventListener("click", () => { $("newChatModal").hidden = true; });
    $("userSearch").addEventListener("input", (e) => searchUsers(e.target.value));

    // group
    $("newGroupBtn").addEventListener("click", () => {
      $("groupModal").hidden = false;
      renderChips(); updateCreateBtn();
      setTimeout(() => $("groupName").focus(), 50);
    });
    $("rrNewGroup").addEventListener("click", () => $("newGroupBtn").click());
    $("closeGroupModal").addEventListener("click", () => { $("groupModal").hidden = true; });
    $("groupName").addEventListener("input", updateCreateBtn);
    $("groupMemberSearch").addEventListener("input", (e) => searchGroupCandidates(e.target.value));
    $("createGroupBtn").addEventListener("click", createGroup);

    // close modals when clicking the dark backdrop
    document.querySelectorAll(".msg-modal").forEach(m => {
      m.addEventListener("click", (e) => { if (e.target === m) m.hidden = true; });
    });

    // archived (toast for now)
    $("archiveOpenBtn").addEventListener("click", () => toast("Archived view coming soon"));

    // thread back (mobile)
    $("threadBack").addEventListener("click", () => {
      document.body.classList.remove("thread-open");
      state.activeKey = null;
      renderList($("searchInput").value);
      $("thread").hidden = true; $("threadEmpty").hidden = false;
    });
    $("mobileBack").addEventListener("click", () => { location.href = "/feed.html"; });

    // helper: can we send right now? (have an active conv OR a peer to lazy-create with)
    const canSend = () => !!state.activeKey || (state.activeKind === "dm" && state.activePeer);

    // composer
    $("composer").addEventListener("submit", (e) => {
      e.preventDefault();
      if (!canSend()) return;
      const t = $("messageInput").value.trim();
      if (!t) return;
      $("messageInput").value = "";
      sendText(t, "", "text");
    });

    // typing
    $("messageInput").addEventListener("input", () => {
      if (state.activeKind !== "dm" || !state.activePeer || !state.activeKey) return;
      if (state.typingTimer) clearTimeout(state.typingTimer);
      if (window.realtime) window.realtime.emit("typing:start", { conversationId: state.activeKey, to: state.activePeer._id });
      state.typingTimer = setTimeout(() => {
        if (window.realtime) window.realtime.emit("typing:stop", { conversationId: state.activeKey, to: state.activePeer._id });
      }, 1500);
    });

    // attach
    $("attachBtn").addEventListener("click", () => { if (canSend()) $("fileInput").click(); });
    $("fileInput").addEventListener("change", async (e) => {
      const f = e.target.files[0]; if (!f || !canSend()) return;
      try {
        toast("Uploading…");
        const up = await uploadFile(f);
        await sendText("", up.url, up.type);
      } catch (err) { toast(err.message); }
      finally { e.target.value = ""; }
    });

    // emoji — naive insert (avoid extra deps)
    $("emojiBtn").addEventListener("click", () => {
      const i = $("messageInput");
      i.value = (i.value || "") + "😊"; i.focus();
    });

    // voice (mic) — hold to record · swipe up to lock · swipe left to cancel
    wireMic();


    // refresh on focus
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden) loadInbox();
    });
  }

  /* ───── boot ───── */
  wire();
  wireSockets();
  loadInbox();

  // auto-open thread if URL says so: ?u=<userId> or ?g=<groupId>
  const url = new URL(location.href);
  const uid = url.searchParams.get("u");
  const gid = url.searchParams.get("g");
  if (uid) {
    api("/api/users/" + uid).then(u => startDMWith(u || { _id: uid, fullName: "User", profilePicture: "" })).catch(() => {});
  } else if (gid) {
    // wait for inbox, then open
    const tick = setInterval(() => {
      const row = state.threads.find(t => t.kind === "group" && t.id === gid);
      if (row) { clearInterval(tick); openThread(row); }
    }, 300);
    setTimeout(() => clearInterval(tick), 6000);
  }
})();
